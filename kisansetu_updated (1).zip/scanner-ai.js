// KisanSetu (AgriLink) - AI Photo-Based Produce Quality & Freshness Scanner

class KisanProduceScanner {
  constructor() {
    this.currentScanResult = null;
    this.sampleScans = window.SEED_DATA ? window.SEED_DATA.sampleProduceScans : [];
  }

  // Analyze an image (via canvas or image element)
  async analyzeProduceImage(imageSource, cropHint = null) {
    return new Promise((resolve) => {
      // Simulate high-fidelity multi-stage Computer Vision pipeline
      setTimeout(() => {
        let matchedSample = null;
        if (cropHint) {
          matchedSample = this.sampleScans.find(s => s.cropName.toLowerCase().includes(cropHint.toLowerCase()));
        }

        if (!matchedSample) {
          // Default to Tomato or random selection
          matchedSample = this.sampleScans[0];
        }

        // Add randomized natural variances and unique verification hash
        const certId = "AGRI-QC-" + Math.floor(100000 + Math.random() * 900000);
        const freshness = Math.min(99, Math.max(85, matchedSample.freshnessScore + (Math.floor(Math.random() * 5) - 2)));
        
        const result = {
          ...matchedSample,
          certId: certId,
          freshnessScore: freshness,
          scannedAt: new Date().toISOString(),
          imageUrl: imageSource || matchedSample.imageUrl,
          boundingBoxes: [
            { label: matchedSample.cropName + " - Primary Batch", x: 15, y: 20, width: 70, height: 60, confidence: "99.2%", status: "healthy" },
            { label: "Surface Texture", x: 35, y: 40, width: 30, height: 30, confidence: "97.8%", status: "firm" }
          ],
          parameters: {
            skinIntegrity: "98.4%",
            colorIndex: matchedSample.colorProfile,
            moistureEst: matchedSample.moistureEst,
            defectRate: matchedSample.blemishDefectPct,
            estimatedShelfLife: matchedSample.shelfLifeDays
          }
        };

        this.currentScanResult = result;
        resolve(result);
      }, 1400);
    });
  }

  // Draw scanning overlays & bounding boxes on canvas
  renderScanCanvas(canvasElement, imageElement, scanData) {
    if (!canvasElement || !imageElement) return;
    const ctx = canvasElement.getContext('2d');
    const width = canvasElement.width = imageElement.naturalWidth || 600;
    const height = canvasElement.height = imageElement.naturalHeight || 400;

    // Clear and draw image
    ctx.clearRect(0, 0, width, height);
    ctx.drawImage(imageElement, 0, 0, width, height);

    if (!scanData) return;

    // Draw AI bounding boxes
    ctx.lineWidth = 3;
    ctx.strokeStyle = '#22c55e'; // Emerald green
    ctx.fillStyle = 'rgba(34, 197, 94, 0.15)';

    scanData.boundingBoxes.forEach(box => {
      const bx = (box.x / 100) * width;
      const by = (box.y / 100) * height;
      const bw = (box.width / 100) * width;
      const bh = (box.height / 100) * height;

      // Box rectangle
      ctx.strokeRect(bx, by, bw, bh);
      ctx.fillRect(bx, by, bw, bh);

      // Label background
      ctx.fillStyle = '#15803d';
      ctx.fillRect(bx, by - 24, Math.min(220, bw), 24);

      // Label text
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 12px Inter, sans-serif';
      ctx.fillText(`✓ ${box.label} (${box.confidence})`, bx + 6, by - 7);
    });

    // Draw corner markers
    const len = 15;
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 4;
    // Top-left
    ctx.beginPath(); ctx.moveTo(10, 10 + len); ctx.lineTo(10, 10); ctx.lineTo(10 + len, 10); ctx.stroke();
    // Top-right
    ctx.beginPath(); ctx.moveTo(width - 10 - len, 10); ctx.lineTo(width - 10, 10); ctx.lineTo(width - 10, 10 + len); ctx.stroke();
    // Bottom-left
    ctx.beginPath(); ctx.moveTo(10, height - 10 - len); ctx.lineTo(10, height - 10); ctx.lineTo(10 + len, height - 10); ctx.stroke();
    // Bottom-right
    ctx.beginPath(); ctx.moveTo(width - 10 - len, height - 10); ctx.lineTo(width - 10, height - 10); ctx.lineTo(width - 10, height - 10 - len); ctx.stroke();
  }
}

if (typeof window !== 'undefined') {
  window.KisanProduceScanner = KisanProduceScanner;
}
