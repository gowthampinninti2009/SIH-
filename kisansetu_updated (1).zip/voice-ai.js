// KisanSetu (AgriLink) - AI Voice Assistant & "Sell Now" Voice-to-Listing NLP Engine

class KisanVoiceAI {
  constructor() {
    this.recognition = null;
    this.isListening = false;
    this.currentLanguage = 'en-IN';
    this.synth = window.speechSynthesis || null;
    this.initSpeechRecognition();
  }

  initSpeechRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = false;
      this.recognition.interimResults = true;
      this.recognition.lang = this.currentLanguage;
    }
  }

  setLanguage(langCode) {
    const langMap = {
      en: 'en-IN',
      hi: 'hi-IN',
      te: 'te-IN',
      ta: 'ta-IN',
      mr: 'mr-IN',
      pa: 'pa-IN',
      kn: 'kn-IN',
      bn: 'bn-IN'
    };
    this.currentLanguage = langMap[langCode] || 'en-IN';
    if (this.recognition) {
      this.recognition.lang = this.currentLanguage;
    }
  }

  startListening(onResult, onStatusChange, onError) {
    if (!this.recognition) {
      if (onStatusChange) onStatusChange('simulated');
      return false;
    }

    try {
      this.isListening = true;
      if (onStatusChange) onStatusChange('listening');

      this.recognition.onresult = (event) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          transcript += event.results[i][0].transcript;
        }
        if (onResult) onResult(transcript, event.results[event.results.length - 1].isFinal);
      };

      this.recognition.onerror = (event) => {
        console.warn('Speech recognition error:', event.error);
        this.isListening = false;
        if (onError) onError(event.error);
        if (onStatusChange) onStatusChange('idle');
      };

      this.recognition.onend = () => {
        this.isListening = false;
        if (onStatusChange) onStatusChange('idle');
      };

      this.recognition.start();
      return true;
    } catch (e) {
      console.warn('Could not start microphone, using fallback:', e);
      this.isListening = false;
      if (onStatusChange) onStatusChange('simulated');
      return false;
    }
  }

  stopListening() {
    if (this.recognition && this.isListening) {
      this.recognition.stop();
      this.isListening = false;
    }
  }

  speak(text, lang = 'hi-IN') {
    if (!this.synth) return;
    try {
      this.synth.cancel(); // Stop any ongoing speech
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      utterance.pitch = 1.0;
      
      // Attempt to pick a voice matching language
      const voices = this.synth.getVoices();
      const matchedVoice = voices.find(v => v.lang.startsWith(lang.substring(0, 2)));
      if (matchedVoice) utterance.voice = matchedVoice;
      
      this.synth.speak(utterance);
    } catch (e) {
      console.warn('TTS not supported or audio blocked:', e);
    }
  }

  // AI NLP Extraction: Turns unstructured spoken sentences into structured produce listings
  parseSpokenListing(text) {
    const cleanText = text.toLowerCase();
    const result = {
      rawText: text,
      crop: "Tomato",
      variety: "Hybrid Standard",
      quantity: 50,
      unit: "quintal",
      pricePerUnit: 2200,
      location: "Local Farm Area",
      organicCertified: false,
      qualityGrade: "Grade A",
      shelfLifeDays: 30,
      moistureContent: "Standard",
      confidence: 0.95
    };

    // 1. Crop Detection
    const crops = [
      { name: "Paddy (Rice)", keywords: ["paddy", "rice", "dhan", "chawal", "వరి", "धान", "तांदूळ", "ਚੌਲ", "நெல்"] },
      { name: "Wheat", keywords: ["wheat", "gehun", "gehu", "kanak", "గోధుమ", "गेहूं", "गहू", "ਕਣਕ", "கோதுமை"] },
      { name: "Tomato", keywords: ["tomato", "tamatar", "tamata", "టమోటా", "टमाटर", "टोमॅटो", "ਟਮਾਟਰ", "தக்காளி"] },
      { name: "Onion", keywords: ["onion", "pyaz", "kanda", "ullipayalu", "ఉల్లిపాయ", "प्याज", "कांदा", "ਗੰਢੇ", "வெங்காயம்"] },
      { name: "Red Chilli", keywords: ["chilli", "mirchi", "mirch", "lal mirch", "మిరపకాయ", "मिर्च", "लाल मिरची", "மிளகாய்"] },
      { name: "Potato", keywords: ["potato", "aloo", "alu", "బంగాళాదుంప", "आलू", "बटाटा", "ਆਲੂ", "உருளைக்கிழங்கு"] },
      { name: "Soybean", keywords: ["soybean", "soya", "సోయాబీన్", "सोयाबीन"] },
      { name: "Cotton", keywords: ["cotton", "kapas", "patti", "పత్తి", "कपास", "ਕਪਾਹ", "பருத்தி"] },
      { name: "Pomegranate", keywords: ["pomegranate", "anar", "dalimbe", "దానిమ్మ", "अनार", "डाळिंब"] },
      { name: "Garlic", keywords: ["garlic", "lahsun", "lasun", "వెల్లుల్లి", "लहसुन", "लसूण", "ਪੂਤੀ"] }
    ];

    for (const c of crops) {
      if (c.keywords.some(k => cleanText.includes(k))) {
        result.crop = c.name;
        break;
      }
    }

    // 2. Variety Detection
    if (cleanText.includes("sona masoori") || cleanText.includes("sonamasoori") || cleanText.includes("सोना मसूरी") || cleanText.includes("సోనా మసూరి")) {
      result.variety = "Sona Masoori (A-Grade)";
    } else if (cleanText.includes("basmati") || cleanText.includes("1121") || cleanText.includes("बासमती")) {
      result.variety = "Basmati 1121 Premium";
    } else if (cleanText.includes("sharbati") || cleanText.includes("शरबती")) {
      result.variety = "Sharbati Gold Grain";
    } else if (cleanText.includes("lokwan") || cleanText.includes("लोकवन")) {
      result.variety = "Lokwan High Gluten";
    } else if (cleanText.includes("nashik red") || cleanText.includes("garwa") || cleanText.includes("लाल कांदा")) {
      result.variety = "Nashik Red Garwa";
    } else if (cleanText.includes("teja") || cleanText.includes("guntur")) {
      result.variety = "Guntur Teja Super Hot";
    } else if (cleanText.includes("himsona") || cleanText.includes("hybrid")) {
      result.variety = "Hybrid Firm Red";
    }

    // 3. Quantity & Unit Detection
    const qtyMatch = cleanText.match(/(\d+)\s*(quintal|quintals|qtl|bags|bag|bori|basta|ton|tons|kg|kilo|क्विंटल|बोरी|बस्ता|కిలో|క్వింటా)/i);
    if (qtyMatch) {
      result.quantity = parseInt(qtyMatch[1], 10);
      const u = qtyMatch[2].toLowerCase();
      if (u.includes("bag") || u.includes("bori") || u.includes("basta") || u.includes("बोरी")) {
        result.unit = "bags (50kg)";
      } else if (u.includes("ton")) {
        result.unit = "quintal";
        result.quantity = result.quantity * 10; // Convert tons to quintals
      } else if (u.includes("kg") || u.includes("kilo")) {
        result.unit = "kg";
      } else {
        result.unit = "quintal";
      }
    } else {
      // General number match
      const genericNumbers = cleanText.match(/\b(\d{1,4})\b/g);
      if (genericNumbers && genericNumbers.length > 0) {
        result.quantity = parseInt(genericNumbers[0], 10);
      }
    }

    // 4. Price Detection
    const priceMatch = cleanText.match(/(?:₹|rs\.?|rate|price|bhav|at|asking|₹\s*|रुपये|भाव|ధర)?\s*(\d{3,6})\b/i);
    if (priceMatch) {
      // Look for the largest 3 to 5-digit number or price pattern
      const numbers = cleanText.match(/\b\d{3,5}\b/g);
      if (numbers) {
        // usually price per quintal is in the 1000-30000 range
        const priceCandidate = numbers.find(n => parseInt(n, 10) >= 1000);
        if (priceCandidate) {
          result.pricePerUnit = parseInt(priceCandidate, 10);
        }
      }
    }

    // 5. Location Detection
    const locations = [
      "Guntur", "Nashik", "Ludhiana", "Kurnool", "Indore", "Kolar", "Bhopal", 
      "Karnal", "Hyderabad", "Delhi", "Pune", "Nizamabad", "Warangal", "Amritsar", "Nagpur"
    ];
    for (const loc of locations) {
      if (cleanText.includes(loc.toLowerCase())) {
        result.location = loc;
        break;
      }
    }

    // 6. Organic / Quality Keywords
    if (cleanText.includes("organic") || cleanText.includes("jaivik") || cleanText.includes("जैविक") || cleanText.includes("సేంద్రీయ")) {
      result.organicCertified = true;
      result.qualityGrade = "Grade A+ (Certified Organic)";
    }

    if (cleanText.includes("sun dried") || cleanText.includes("dry") || cleanText.includes("सूखा")) {
      result.moistureContent = "11.5% - 12.5% (Sun Dried)";
    }

    return result;
  }

  // Pre-configured voice samples for instantaneous testing across languages
  getPresetVoicePrompts() {
    return [
      {
        lang: "hi",
        label: "🇮🇳 हिन्दी (Hindi)",
        text: "मेरे पास गुंटूर में 60 क्विंटल सोना मसूरी धान है, भाव ₹2600 प्रति क्विंटल चाहिए",
        caption: "60 क्विंटल सोना मसूरी धान @ ₹2600/क्विंटल"
      },
      {
        lang: "en",
        label: "🇬🇧 English",
        text: "I have 120 quintals of Nashik Red Onion ready to dispatch at ₹2850 per quintal in Nashik",
        caption: "120 quintals Nashik Red Onion @ ₹2850/qtl"
      },
      {
        lang: "te",
        label: "🇮🇳 తెలుగు (Telugu)",
        text: "నా వద్ద కర్నూలులో 40 క్వింటాళ్ల ఎర్ర మిరపకాయలు తేజా రకం ఉన్నాయి, క్వింటాకు ₹22000 ధర ఆశిస్తున్నాను",
        caption: "40 క్వింటాళ్ల తేజా ఎర్ర మిరప @ ₹22000/క్వింటా"
      },
      {
        lang: "mr",
        label: "🇮🇳 मराठी (Marathi)",
        text: "माझ्याकडे नाशिकमध्ये 100 क्विंटल दर्जेदार लाल कांदा आहे, भाव ₹2900 प्रति क्विंटल हवा आहे",
        caption: "100 क्विंटल लाल कांदा @ ₹2900/क्विंटल"
      },
      {
        lang: "pa",
        label: "🇮🇳 ਪੰਜਾਬੀ (Punjabi)",
        text: "ਮੇਰੇ ਕੋਲ ਲੁਧਿਆਣਾ ਵਿੱਚ 150 ਕੁਇੰਟਲ ਸ਼ਰਬਤੀ ਕਣਕ ਹੈ, ਰੇਟ ₹2920 ਪ੍ਰਤੀ ਕੁਇੰਟਲ ਚਾਹੀਦਾ ਹੈ",
        caption: "150 ਕੁਇੰਟਲ ਸ਼ਰਬਤੀ ਕਣਕ @ ₹2920/ਕੁਇੰਟਲ"
      }
    ];
  }
}

if (typeof window !== 'undefined') {
  window.KisanVoiceAI = KisanVoiceAI;
}
