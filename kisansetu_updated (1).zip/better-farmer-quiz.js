// KisanSetu (AgriLink) - Better Farmer Diagnostic Assessment & Reward Discounts Wallet

class BetterFarmerEngine {
  constructor() {
    this.quizQuestions = window.SEED_DATA ? window.SEED_DATA.betterFarmerQuestions : [];
    this.rewardVouchers = this.loadStoredVouchers();
    this.userScore = parseInt(localStorage.getItem('kisan_farmer_score') || '0', 10);
    this.completedQuiz = localStorage.getItem('kisan_quiz_completed') === 'true';
    this.lastAssessmentResult = this.loadStoredAssessment();
  }

  loadStoredVouchers() {
    const defaultVouchers = window.SEED_DATA ? window.SEED_DATA.rewardVouchers : [];
    try {
      const stored = localStorage.getItem('kisan_vouchers');
      return stored ? JSON.parse(stored) : defaultVouchers;
    } catch (e) {
      return defaultVouchers;
    }
  }

  loadStoredAssessment() {
    try {
      const stored = localStorage.getItem('kisan_last_assessment');
      return stored ? JSON.parse(stored) : null;
    } catch (e) {
      return null;
    }
  }

  saveData() {
    localStorage.setItem('kisan_vouchers', JSON.stringify(this.rewardVouchers));
    localStorage.setItem('kisan_farmer_score', this.userScore.toString());
    localStorage.setItem('kisan_quiz_completed', this.completedQuiz.toString());
    if (this.lastAssessmentResult) {
      localStorage.setItem('kisan_last_assessment', JSON.stringify(this.lastAssessmentResult));
    }
  }

  // Calculate diagnostic result and custom farming advisory roadmap
  evaluateAssessment(answers) {
    let totalScore = 0;
    const recommendations = [];
    const unlockedVouchers = [];

    // Evaluate answers
    this.quizQuestions.forEach((q, idx) => {
      const selectedIndex = answers[q.id];
      if (selectedIndex !== undefined && q.options[selectedIndex]) {
        const opt = q.options[selectedIndex];
        totalScore += opt.points;
        
        if (opt.points < 20) {
          recommendations.push({
            category: q.category,
            issue: q.question,
            action: opt.improvementAction,
            impact: opt.potentialGain
          });
        }
      }
    });

    this.userScore = Math.min(100, Math.round(totalScore));
    this.completedQuiz = true;

    // Determine farmer badge
    let badge = "Novice Kisan 🌱";
    if (this.userScore >= 85) badge = "Master Progressive Farmer 🏆";
    else if (this.userScore >= 65) badge = "Advanced Smart Kisan ⭐";
    else if (this.userScore >= 45) badge = "Developing Kisan 🌾";

    // Unlock rewards based on score
    if (this.userScore >= 40) {
      this.rewardVouchers.forEach(v => {
        if (v.requiredScore <= this.userScore && !v.unlocked) {
          v.unlocked = true;
          unlockedVouchers.push(v);
        }
      });
    }

    this.lastAssessmentResult = {
      score: this.userScore,
      badge: badge,
      date: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
      recommendations: recommendations,
      unlockedVouchersCount: unlockedVouchers.length
    };

    this.saveData();
    return this.lastAssessmentResult;
  }

  // Redeem a voucher code
  redeemVoucher(voucherId) {
    const v = this.rewardVouchers.find(item => item.id === voucherId);
    if (!v) return { success: false, msg: "Voucher not found" };
    if (!v.unlocked) return { success: false, msg: "Complete diagnostic quiz with higher score to unlock!" };
    if (v.isRedeemed) return { success: false, msg: "Already redeemed!" };

    v.isRedeemed = true;
    this.saveData();
    return { success: true, code: v.couponCode, title: v.title, discount: v.discountValue };
  }
}

if (typeof window !== 'undefined') {
  window.BetterFarmerEngine = BetterFarmerEngine;
}
