# KisanSetu TCP Server - accepts ANY host header (tunnel-compatible)
$port = 5173
$root = $PSScriptRoot

$mimeMap = @{
    ".html" = "text/html; charset=utf-8"
    ".css"  = "text/css; charset=utf-8"
    ".js"   = "application/javascript; charset=utf-8"
    ".json" = "application/json; charset=utf-8"
    ".png"  = "image/png"
    ".jpg"  = "image/jpeg"
    ".jpeg" = "image/jpeg"
    ".svg"  = "image/svg+xml"
    ".ico"  = "image/x-icon"
}

$endpoint = New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Any, $port)
$tcpListener = New-Object System.Net.Sockets.TcpListener($endpoint)

function Send-Response($stream, $statusCode, $statusText, $contentType, $bodyBytes) {
    $corsHeaders = "Access-Control-Allow-Origin: *`r`nAccess-Control-Allow-Methods: GET, POST, OPTIONS`r`nAccess-Control-Allow-Headers: *"
    $header = "HTTP/1.1 $statusCode $statusText`r`nContent-Type: $contentType`r`n$corsHeaders`r`nContent-Length: $($bodyBytes.Length)`r`nConnection: close`r`n`r`n"
    $headerBytes = [System.Text.Encoding]::UTF8.GetBytes($header)
    $stream.Write($headerBytes, 0, $headerBytes.Length)
    $stream.Write($bodyBytes, 0, $bodyBytes.Length)
    $stream.Flush()
}

Write-Host "KisanSetu server running on http://localhost:$port (TCP - tunnel compatible)"
Write-Host "Press Ctrl+C to stop."

$tcpListener.Start()

try {
    while ($true) {
        $client = $tcpListener.AcceptTcpClient()
        $stream = $client.GetStream()
        $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8)

        # Read request line
        $requestLine = $reader.ReadLine()
        if ([string]::IsNullOrWhiteSpace($requestLine)) {
            $client.Close()
            continue
        }

        # Drain all headers
        $line = $reader.ReadLine()
        while (-not [string]::IsNullOrEmpty($line)) {
            $line = $reader.ReadLine()
        }

        $parts = $requestLine.Split(' ')
        $method = $parts[0]
        $rawUrl = if ($parts.Length -gt 1) { $parts[1] } else { "/" }
        $urlPath = $rawUrl.Split('?')[0].TrimStart('/')
        if ([string]::IsNullOrEmpty($urlPath)) { $urlPath = "index.html" }

        $filePath = Join-Path $root $urlPath

        try {
            if ($method -eq "OPTIONS") {
                $emptyBytes = [System.Text.Encoding]::UTF8.GetBytes("")
                Send-Response $stream 200 "OK" "text/plain" $emptyBytes
            }
            elseif (Test-Path $filePath -PathType Leaf) {
                $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
                $ct = if ($mimeMap.ContainsKey($ext)) { $mimeMap[$ext] } else { "application/octet-stream" }
                $bodyBytes = [System.IO.File]::ReadAllBytes($filePath)
                Send-Response $stream 200 "OK" $ct $bodyBytes
            }
            else {
                $bodyBytes = [System.Text.Encoding]::UTF8.GetBytes("<h1>404 - Not Found: $urlPath</h1>")
                Send-Response $stream 404 "Not Found" "text/html; charset=utf-8" $bodyBytes
            }
        } catch {}

        $client.Close()
    }
} finally {
    $tcpListener.Stop()
    Write-Host "Server stopped."
}
