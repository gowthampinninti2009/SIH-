// KisanSetu (AgriLink) - Main Application Controller & Store

class KisanApp {
  constructor() {
    this.currentLang = localStorage.getItem('kisan_lang') || 'en';
    this.userRole = localStorage.getItem('kisan_role') || 'farmer'; // 'farmer' | 'buyer'
    this.activeTab = 'marketplace'; // 'marketplace', 'mandi', 'sell_now', 'scan_produce', 'better_farmer', 'ml_engine', 'whatsapp_alerts', 'farmer_duels', 'demands', 'groups', 'logistics', 'orders', 'earnings'
    
    // Instantiate core & advanced engines
    this.voiceAI = new KisanVoiceAI();
    this.scannerAI = new KisanProduceScanner();
    this.marketEngine = new KisanMarketEngine();
    this.betterFarmerEngine = new BetterFarmerEngine();
    this.mlEngine = new MultiVariableMLEngine();
    this.waBridge = new WhatsAppBridgeEngine();
    this.duelsEngine = new FarmerDuelsEngine();
    this.climatePlanner = new ClimateResiliencePlanner();

    // Data stores (with LocalStorage cache fallback)
    this.listings = this.loadStoredData('kisan_listings', window.SEED_DATA.listings);
    this.demands = this.loadStoredData('kisan_demands', window.SEED_DATA.demands);
    this.groupPools = this.loadStoredData('kisan_pools', window.SEED_DATA.groupPools);
    this.orders = this.loadStoredData('kisan_orders', window.SEED_DATA.orders);
    this.chatThreads = this.loadStoredData('kisan_chats', window.SEED_DATA.chatThreads);
    this.transporters = window.SEED_DATA.transporters;

    // Filters & Simulation state
    this.selectedCropFilter = 'All';
    this.searchQuery = '';
    this.selectedMandiCrop = 'Tomato';
    this.arbitrageQty = 50;
    this.arbitrageRate = 25;

    // ML Engine state
    this.mlCrop = 'Tomato';
    this.mlBasePrice = 2200;
    this.mlSoil = 'Black Loamy';
    this.mlWeather = 'Excess Rain';
    this.mlFestival = 'Diwali / Wedding Surge';
    this.mlIrrigation = 'Drip';
    this.lastMLResult = null;

    // Quiz state
    this.quizAnswers = {};
    this.quizResult = this.betterFarmerEngine.lastAssessmentResult;

    // Active modal states
    this.activeChatListingId = null;
    this.currentScan = null;
    this.isDeviceFrame = false;

    // Ticker state
    this.tickerData = [];
    this.tickerHistory = {};
    this.tickerInterval = null;
    this.tickerSortMode = 'all'; // 'all', 'gainers', 'losers'
    this.initTickerData();

    this.init();
  }

  loadStoredData(key, defaultData) {
    try {
      const stored = localStorage.getItem(key);
      return stored ? JSON.parse(stored) : defaultData;
    } catch (e) {
      return defaultData;
    }
  }

  saveStoredData(key, data) {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.warn('Storage save failed:', e);
    }
  }

  init() {
    this.voiceAI.setLanguage(this.currentLang);
    this.lastMLResult = this.mlEngine.predictPrice({
      crop: this.mlCrop,
      basePrice: this.mlBasePrice,
      soilType: this.mlSoil,
      weatherAnomaly: this.mlWeather,
      festivalSeason: this.mlFestival,
      irrigation: this.mlIrrigation
    });
    this.render();
    this.bindEvents();
    this.checkOnlineStatus();
  }

  t(key) {
    const langDict = window.TRANSLATIONS[this.currentLang] || window.TRANSLATIONS.en;
    return langDict[key] || window.TRANSLATIONS.en[key] || key;
  }

  setLanguage(lang) {
    this.currentLang = lang;
    localStorage.setItem('kisan_lang', lang);
    this.voiceAI.setLanguage(lang);
    this.render();
  }

  setUserRole(role) {
    this.userRole = role;
    localStorage.setItem('kisan_role', role);
    this.render();
  }

  // setActiveTab is defined below with ticker start/stop logic


  toggleDeviceFrame() {
    this.isDeviceFrame = !this.isDeviceFrame;
    const container = document.getElementById('app-shell-container');
    if (container) {
      if (this.isDeviceFrame) {
        container.className = "device-mockup-wrapper";
      } else {
        container.className = "w-full min-h-screen bg-slate-50";
      }
    }
  }

  checkOnlineStatus() {
    window.addEventListener('online', () => this.showToast('🟢 Back Online! Syncing listings...'));
    window.addEventListener('offline', () => this.showToast('🟠 You are Offline. Local mode enabled.'));
  }

  showToast(message, duration = 3000) {
    const toast = document.createElement('div');
    toast.className = 'fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-slate-900/95 text-white px-5 py-2.5 rounded-full shadow-xl border border-slate-700 text-sm font-medium animate-bounce flex items-center gap-2';
    toast.innerHTML = `<span>${message}</span>`;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.remove();
    }, duration);
  }

  // --- Voice-To-Listing Handlers ---
  handleVoiceStart() {
    const voiceStatus = document.getElementById('voice-status-text');
    const voiceCard = document.getElementById('voice-listening-card');
    
    if (voiceCard) voiceCard.classList.remove('hidden');
    if (voiceStatus) voiceStatus.innerText = this.t('voiceListening');

    const started = this.voiceAI.startListening(
      (transcript, isFinal) => {
        const transcriptEl = document.getElementById('voice-transcript-output');
        if (transcriptEl) transcriptEl.innerText = `"${transcript}"`;
        if (isFinal) {
          this.processVoiceTranscript(transcript);
        }
      },
      (status) => {
        if (status === 'simulated') {
          const presetsEl = document.getElementById('voice-presets-container');
          if (presetsEl) presetsEl.classList.remove('hidden');
        }
      },
      (error) => {
        this.showToast('Microphone: ' + error + '. You can also tap 1-click voice simulation buttons below.');
      }
    );

    if (!started) {
      const presetsEl = document.getElementById('voice-presets-container');
      if (presetsEl) presetsEl.classList.remove('hidden');
    }
  }

  handleVoiceStop() {
    this.voiceAI.stopListening();
    const transcriptEl = document.getElementById('voice-transcript-output');
    const text = transcriptEl ? transcriptEl.innerText.replace(/"/g, '') : '';
    if (text && text.length > 5) {
      this.processVoiceTranscript(text);
    }
  }

  processVoiceTranscript(transcriptText) {
    if (this.activeTab !== 'sell_now') {
      this.setActiveTab('sell_now');
    }
    setTimeout(() => {
      const parsed = this.voiceAI.parseSpokenListing(transcriptText);
      
      const cropEl = document.getElementById('sell-crop-name');
      if (cropEl) cropEl.value = parsed.crop;
      const varEl = document.getElementById('sell-variety');
      if (varEl) varEl.value = parsed.variety;
      const qtyEl = document.getElementById('sell-quantity');
      if (qtyEl) qtyEl.value = parsed.quantity;
      const unitEl = document.getElementById('sell-unit');
      if (unitEl) unitEl.value = parsed.unit;
      const priceEl = document.getElementById('sell-price');
      if (priceEl) priceEl.value = parsed.pricePerUnit;
      const locEl = document.getElementById('sell-location');
      if (locEl) locEl.value = parsed.location;
      const orgEl = document.getElementById('sell-organic');
      if (orgEl) orgEl.checked = parsed.organicCertified;

      const parsedCard = document.getElementById('voice-parsed-preview');
      if (parsedCard) {
        parsedCard.classList.remove('hidden');
        parsedCard.innerHTML = `
          <div class="bg-emerald-50 border border-emerald-300 rounded-xl p-4 text-emerald-900 shadow-sm animate-pulse">
            <div class="flex items-center gap-2 font-bold text-base mb-1">
              <span class="text-emerald-600 text-lg">✓</span> AI Extracted Details from Voice:
            </div>
            <div class="grid grid-cols-2 gap-2 text-xs">
              <div><strong>🌾 Crop:</strong> ${parsed.crop} (${parsed.variety})</div>
              <div><strong>⚖️ Quantity:</strong> ${parsed.quantity} ${parsed.unit}</div>
              <div><strong>💰 Asking Rate:</strong> ₹${parsed.pricePerUnit} / quintal</div>
              <div><strong>📍 Location:</strong> ${parsed.location}</div>
            </div>
            <div class="mt-2 text-xs text-emerald-700">Ready to publish! Review details below and click Publish.</div>
          </div>
        `;
      }

      this.showToast(`✨ AI detected: ${parsed.quantity} ${parsed.unit} ${parsed.crop} @ ₹${parsed.pricePerUnit}`);
      this.voiceAI.speak(`Found ${parsed.quantity} quintals of ${parsed.crop} at ${parsed.pricePerUnit} rupees. Listing prepared.`);
    }, 80);
  }

  // --- Publish Listing ---
  publishNewListing(e) {
    if (e) e.preventDefault();
    const crop = document.getElementById('sell-crop-name')?.value || 'Tomato';
    const variety = document.getElementById('sell-variety')?.value || 'Standard Grade';
    const quantity = parseFloat(document.getElementById('sell-quantity')?.value) || 50;
    const unit = document.getElementById('sell-unit')?.value || 'quintal';
    const pricePerUnit = parseFloat(document.getElementById('sell-price')?.value) || 2200;
    const location = document.getElementById('sell-location')?.value || 'Local Area';
    const isOrganic = document.getElementById('sell-organic')?.checked || false;
    const description = document.getElementById('sell-description')?.value || 'Quality produce direct from farm.';

    const newListing = {
      id: "list-" + Date.now(),
      farmerId: "current-user",
      farmerName: "Gowtham Farmer (You)",
      phone: "+91 99001 22334",
      location: location,
      distanceKm: 5,
      crop: crop,
      variety: variety || "Standard Grade",
      quantity: quantity,
      unit: unit,
      minOrderQty: 10,
      pricePerUnit: pricePerUnit,
      mandiRefPrice: Math.round(pricePerUnit * 0.95),
      priceAdvantage: "+₹" + Math.round(pricePerUnit * 0.05) + "/qtl fair price",
      harvestDate: new Date().toISOString().split('T')[0],
      isPreBooking: false,
      organicCertified: isOrganic,
      qualityScore: this.currentScan ? this.currentScan.freshnessScore : 94,
      qualityGrade: this.currentScan ? this.currentScan.grade : "Grade A Standard",
      moistureContent: this.currentScan ? this.currentScan.moistureEst : "12.0%",
      shelfLifeDays: this.currentScan ? parseInt(this.currentScan.shelfLifeDays) || 30 : 30,
      photos: [
        this.currentScan ? this.currentScan.imageUrl : "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=600&q=80"
      ],
      description: description,
      trustScore: 5.0,
      dealsCompleted: 1,
      verifiedLandRecord: true,
      logisticsAssistance: true,
      createdAt: new Date().toISOString()
    };

    this.listings.unshift(newListing);
    this.saveStoredData('kisan_listings', this.listings);
    
    this.showToast('🎉 Your produce listing is live on the buyer marketplace!');
    this.setActiveTab('marketplace');
  }

  // --- Produce Scanner Handlers ---
  async handleProduceScan(sampleId = null, customImgUrl = null) {
    const scanContainer = document.getElementById('scan-result-card');
    const scanBtn = document.getElementById('scan-trigger-btn');
    if (scanBtn) scanBtn.innerHTML = `<span>⏳ AI Analyzing Produce Micro-Features...</span>`;

    let imgSource = customImgUrl;
    let cropHint = null;

    if (sampleId) {
      const sample = window.SEED_DATA.sampleProduceScans.find(s => s.id === sampleId);
      if (sample) {
        imgSource = sample.imageUrl;
        cropHint = sample.cropName;
      }
    }

    const result = await this.scannerAI.analyzeProduceImage(imgSource, cropHint);
    this.currentScan = result;

    if (scanBtn) scanBtn.innerHTML = `<span>📷 Scan Produce Quality with AI</span>`;
    
    if (scanContainer) {
      scanContainer.classList.remove('hidden');
      scanContainer.innerHTML = `
        <div class="bg-white border-2 border-emerald-500 rounded-2xl p-5 shadow-lg space-y-4">
          <div class="flex items-center justify-between border-b pb-3">
            <div>
              <span class="inline-block bg-emerald-100 text-emerald-800 font-bold text-xs px-2.5 py-1 rounded-full uppercase tracking-wider">AI Verified Certificate</span>
              <h3 class="text-lg font-bold text-slate-800 mt-1">${result.cropName} (${result.variety})</h3>
            </div>
            <div class="text-right">
              <div class="text-2xl font-black text-emerald-600">${result.freshnessScore}<span class="text-sm font-normal text-slate-500">/100</span></div>
              <div class="text-xs font-semibold text-emerald-700">${result.grade}</div>
            </div>
          </div>

          <div class="relative rounded-xl overflow-hidden bg-slate-900 border border-slate-700">
            <canvas id="scan-preview-canvas" class="w-full h-48 object-cover"></canvas>
            <div class="absolute top-2 left-2 bg-slate-900/80 backdrop-blur text-white text-[10px] px-2 py-1 rounded">
              🔍 Defect Rate: ${result.blemishDefectPct} | Moisture: ${result.moistureEst}
            </div>
          </div>

          <div class="grid grid-cols-2 gap-2 text-xs">
            <div class="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
              <span class="text-slate-500 block">Shelf Life:</span>
              <strong class="text-slate-800">${result.shelfLifeDays}</strong>
            </div>
            <div class="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
              <span class="text-slate-500 block">Recommended Price:</span>
              <strong class="text-emerald-700">${result.recommendedPrice}</strong>
            </div>
          </div>

          <div class="bg-emerald-50 p-3 rounded-xl border border-emerald-200 text-xs text-emerald-900">
            <strong>🤖 AI Advisory:</strong> ${result.aiAdvice}
          </div>

          <div class="flex items-center justify-between text-[11px] text-slate-500 border-t pt-2">
            <span>Cert ID: <code>${result.certId}</code></span>
            <span>Confidence: ${result.confidence}</span>
          </div>

          <button onclick="kisanApp.attachScanToSellForm()" class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-xl shadow-md transition flex items-center justify-center gap-2">
            <span>✓ Attach Quality Certificate to Sell Listing</span>
          </button>
        </div>
      `;

      const canvas = document.getElementById('scan-preview-canvas');
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        this.scannerAI.renderScanCanvas(canvas, img, result);
      };
      img.src = result.imageUrl;
    }
  }

  attachScanToSellForm() {
    if (!this.currentScan) return;
    this.setActiveTab('sell_now');
    setTimeout(() => {
      const cropEl = document.getElementById('sell-crop-name');
      if (cropEl) cropEl.value = this.currentScan.cropName;
      const varEl = document.getElementById('sell-variety');
      if (varEl) varEl.value = this.currentScan.variety;
      const descEl = document.getElementById('sell-description');
      if (descEl) descEl.value = `Verified with AI Quality Score: ${this.currentScan.freshnessScore}/100 (${this.currentScan.grade}). Moisture: ${this.currentScan.moistureEst}. Shelf Life: ${this.currentScan.shelfLifeDays}. Digital Cert #${this.currentScan.certId}.`;
      this.showToast('✅ AI Freshness Certificate attached to your listing form!');
    }, 150);
  }

  // --- Better Farmer Q&A Assessment Handlers ---
  recordQuizAnswer(questionId, optionIndex) {
    this.quizAnswers[questionId] = optionIndex;
    this.render();
  }

  submitFarmerAssessment() {
    const questions = this.betterFarmerEngine.quizQuestions;
    const answeredCount = Object.keys(this.quizAnswers).length;
    if (answeredCount < questions.length) {
      this.showToast(`Please answer all ${questions.length} questions to receive your diagnostic score & discounts!`);
      return;
    }

    const result = this.betterFarmerEngine.evaluateAssessment(this.quizAnswers);
    this.quizResult = result;
    this.render();
    this.showToast(`🏆 Assessment Complete! Score: ${result.score}/100. New Reward Vouchers Unlocked!`);
  }

  redeemRewardVoucher(voucherId) {
    const res = this.betterFarmerEngine.redeemVoucher(voucherId);
    if (res.success) {
      this.render();
      this.showToast(`🎉 Voucher Redeemed! Use code ${res.code} for ${res.discount}.`);
    } else {
      this.showToast(res.msg);
    }
  }

  // --- Multi-Variable ML Price Prediction Handlers ---
  runMLPricePrediction() {
    this.lastMLResult = this.mlEngine.predictPrice({
      crop: this.mlCrop,
      basePrice: this.mlBasePrice,
      soilType: this.mlSoil,
      weatherAnomaly: this.mlWeather,
      festivalSeason: this.mlFestival,
      irrigation: this.mlIrrigation
    });
    this.render();
    this.showToast(`🤖 ML Price Model executed for ${this.mlCrop}: Target ₹${this.lastMLResult.predictedPrice}/qtl`);
  }

  recalibrateMLEngine() {
    const feedback = this.mlEngine.recalibrateModel();
    this.runMLPricePrediction();
    this.showToast(`⚡ ${feedback.status} (${feedback.varianceReduced})`);
  }

  // --- WhatsApp Alerts & Simulator Handlers ---
  openWhatsAppSimulator(type = 'daily_mandi') {
    const modal = document.getElementById('whatsapp-sim-modal');
    if (!modal) return;

    const chatBody = document.getElementById('whatsapp-sim-messages');
    const headerTitle = document.getElementById('whatsapp-sim-title');

    if (type === 'daily_mandi') {
      if (headerTitle) headerTitle.innerText = "🌾 KisanSetu Mandi Alerts";
      const text = this.waBridge.getDailyMandiBroadcastText("Azadpur Mandi");
      if (chatBody) {
        chatBody.innerHTML = `
          <div class="bg-white rounded-2xl rounded-tl-none p-3.5 shadow text-xs text-slate-800 space-y-2 max-w-[90%]">
            <div class="whitespace-pre-line leading-relaxed font-sans">${text.replace(/\*(.*?)\*/g, '<strong>$1</strong>')}</div>
            <div class="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t">
              <span>Verified KisanSetu Bot</span>
              <span>07:00 AM ✓✓</span>
            </div>
          </div>
          <div class="flex gap-2 pt-2">
            <button onclick="kisanApp.setActiveTab('sell_now'); kisanApp.closeWhatsAppSimulator();" class="bg-emerald-700 text-white font-bold px-3 py-1.5 rounded-xl text-xs shadow">
              🎙️ 1-Click Sell Now
            </button>
            <button onclick="kisanApp.setActiveTab('mandi'); kisanApp.closeWhatsAppSimulator();" class="bg-slate-200 text-slate-800 font-bold px-3 py-1.5 rounded-xl text-xs">
              View All Mandis
            </button>
          </div>
        `;
      }
    } else {
      if (headerTitle) headerTitle.innerText = "🏢 FreshBazaar Direct Buyer Offer";
      const text = this.waBridge.getBuyerOfferAlertText("FreshBazaar Retail Chains", "Tomato", 40, 2200, "Bangalore Hub");
      if (chatBody) {
        chatBody.innerHTML = `
          <div class="bg-white rounded-2xl rounded-tl-none p-3.5 shadow text-xs text-slate-800 space-y-2 max-w-[90%]">
            <div class="whitespace-pre-line leading-relaxed font-sans">${text.replace(/\*(.*?)\*/g, '<strong>$1</strong>')}</div>
            <div class="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t">
              <span>Instant Escrow Trade Alert</span>
              <span>10:15 AM ✓✓</span>
            </div>
          </div>
          <div class="flex flex-col gap-1.5 pt-2">
            <button onclick="kisanApp.showToast('🤝 Offer Accepted via WhatsApp! Escrow locked.'); kisanApp.closeWhatsAppSimulator();" class="bg-emerald-600 text-white font-bold py-2 rounded-xl text-xs shadow flex items-center justify-center gap-1">
              ✓ Reply 1: ACCEPT Offer (₹88,000 Escrow)
            </button>
            <button onclick="kisanApp.openChatModal('list-101'); kisanApp.closeWhatsAppSimulator();" class="bg-amber-500 text-slate-950 font-bold py-2 rounded-xl text-xs shadow flex items-center justify-center gap-1">
              💬 Reply 2: Counter Offer Rate
            </button>
          </div>
        `;
      }
    }

    modal.classList.remove('hidden');
  }

  closeWhatsAppSimulator() {
    const modal = document.getElementById('whatsapp-sim-modal');
    if (modal) modal.classList.add('hidden');
  }

  sendRealWhatsAppAlert(type = 'daily_mandi') {
    const text = type === 'daily_mandi'
      ? this.waBridge.getDailyMandiBroadcastText("Azadpur Mandi")
      : this.waBridge.getBuyerOfferAlertText("FreshBazaar Retail", "Tomato", 40, 2200, "Bangalore Hub");
    
    const url = this.waBridge.generateWhatsAppShareUrl(text);
    window.open(url, '_blank');
  }

  // --- WhatsApp-Style Chat & Negotiation ---
  openChatModal(listingId) {
    this.activeChatListingId = listingId;
    const listing = this.listings.find(l => l.id === listingId);
    if (!listing) return;

    if (!this.chatThreads[listingId]) {
      this.chatThreads[listingId] = [
        { sender: "farmer", text: `Namaste! I am ${listing.farmerName}. My ${listing.crop} (${listing.variety}) is ready for dispatch from ${listing.location}.`, time: "Just now" }
      ];
      this.saveStoredData('kisan_chats', this.chatThreads);
    }

    const modal = document.getElementById('chat-negotiation-modal');
    if (modal) {
      modal.classList.remove('hidden');
      this.renderChatThread(listingId);
    }
  }

  closeChatModal() {
    const modal = document.getElementById('chat-negotiation-modal');
    if (modal) modal.classList.add('hidden');
  }

  renderChatThread(listingId) {
    const listing = this.listings.find(l => l.id === listingId);
    const thread = this.chatThreads[listingId] || [];
    const container = document.getElementById('chat-messages-container');
    const headerTitle = document.getElementById('chat-header-title');
    const headerSubtitle = document.getElementById('chat-header-subtitle');

    if (headerTitle && listing) {
      headerTitle.innerText = `${listing.farmerName} • ${listing.crop}`;
      headerSubtitle.innerText = `Asking: ₹${listing.pricePerUnit}/qtl | ${listing.quantity} ${listing.unit} in ${listing.location}`;
    }

    if (container) {
      container.innerHTML = thread.map(msg => {
        const isMe = (this.userRole === 'buyer' && msg.sender === 'buyer') || (this.userRole === 'farmer' && msg.sender === 'farmer');
        return `
          <div class="flex flex-col ${isMe ? 'items-end' : 'items-start'} mb-3">
            <div class="max-w-[82%] rounded-2xl px-4 py-2.5 text-sm shadow-sm ${
              isMe ? 'bg-emerald-600 text-white rounded-br-none' : 'bg-white text-slate-800 border border-slate-200 rounded-bl-none'
            }">
              <p>${msg.text}</p>
              ${msg.isOffer ? `
                <div class="mt-2 pt-2 border-t ${isMe ? 'border-emerald-500' : 'border-slate-200'} text-xs font-semibold">
                  🏷️ Offer: ${msg.offerQty} qtl @ ₹${msg.offerPrice}/qtl (₹${(msg.offerQty * msg.offerPrice).toLocaleString('en-IN')})
                  ${!isMe ? `
                    <div class="mt-2 flex gap-2">
                      <button onclick="kisanApp.acceptChatDeal('${listingId}', ${msg.offerPrice}, ${msg.offerQty})" class="bg-amber-400 hover:bg-amber-500 text-slate-900 font-bold px-3 py-1 rounded-lg text-xs shadow">
                        🤝 Accept & Lock Escrow
                      </button>
                    </div>
                  ` : ''}
                </div>
              ` : ''}
            </div>
            <span class="text-[10px] text-slate-400 mt-1 px-1">${msg.time}</span>
          </div>
        `;
      }).join('');
      container.scrollTop = container.scrollHeight;
    }
  }

  sendChatMessage(customText = null, isOffer = false, price = 0, qty = 0) {
    const input = document.getElementById('chat-input-text');
    const text = customText || (input ? input.value.trim() : '');
    if (!text && !isOffer) return;

    const thread = this.chatThreads[this.activeChatListingId] || [];
    const newMsg = {
      sender: this.userRole,
      text: text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isOffer: isOffer,
      offerPrice: price,
      offerQty: qty
    };

    thread.push(newMsg);
    this.chatThreads[this.activeChatListingId] = thread;
    this.saveStoredData('kisan_chats', this.chatThreads);

    if (input) input.value = '';
    this.renderChatThread(this.activeChatListingId);

    if (this.userRole === 'buyer' && !isOffer) {
      setTimeout(() => {
        const listing = this.listings.find(l => l.id === this.activeChatListingId);
        const reply = {
          sender: "farmer",
          text: `Ji, I can dispatch with certified Grade A bags. Best rate I can provide is ₹${listing.pricePerUnit - 30}/quintal.`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        thread.push(reply);
        this.chatThreads[this.activeChatListingId] = thread;
        this.saveStoredData('kisan_chats', this.chatThreads);
        this.renderChatThread(this.activeChatListingId);
      }, 1200);
    }
  }

  acceptChatDeal(listingId, price, qty) {
    const listing = this.listings.find(l => l.id === listingId);
    if (!listing) return;

    const totalAmt = price * qty;
    const orderId = "ORD-" + Math.floor(1000 + Math.random() * 9000);
    
    const newOrder = {
      id: orderId,
      listingId: listingId,
      crop: listing.crop,
      variety: listing.variety,
      quantity: qty,
      unit: "quintal",
      dealPricePerUnit: price,
      totalAmount: totalAmt,
      escrowStatus: "Funded & Secured",
      farmerName: listing.farmerName,
      buyerName: "FreshBazaar Retail (You)",
      step: 3,
      timeline: [
        { title: `Deal Agreed at ₹${price}/qtl`, time: "Just now", done: true },
        { title: `Buyer Deposited ₹${totalAmt.toLocaleString('en-IN')} in Escrow`, time: "Just now", done: true },
        { title: "Produce Packed & Loaded on Truck", time: "Pending Dispatch", done: false },
        { title: "Transit to Destination Hub", time: "Pending", done: false },
        { title: "Quality Check & Auto Payment Release", time: "Pending Delivery", done: false }
      ]
    };

    this.orders.unshift(newOrder);
    this.saveStoredData('kisan_orders', this.orders);

    this.closeChatModal();
    this.showToast(`🎉 Deal Confirmed! Escrow ₹${totalAmt.toLocaleString('en-IN')} secured.`);
    this.setActiveTab('orders');
  }

  advanceOrderMilestone(orderId) {
    const order = this.orders.find(o => o.id === orderId);
    if (!order) return;

    if (order.step < 5) {
      order.step += 1;
      if (order.step === 4) {
        order.timeline[2].done = true;
        order.timeline[2].time = "Dispatched";
        order.timeline[3].time = "In Transit (Live GPS Active)";
      } else if (order.step === 5) {
        order.timeline[3].done = true;
        order.timeline[4].done = true;
        order.timeline[4].time = "Payment Released to Farmer Bank";
        order.escrowStatus = "Completed & Payout Released";
      }
      this.saveStoredData('kisan_orders', this.orders);
      this.render();
      this.showToast(`📦 Order ${orderId} status advanced to Step ${order.step}/5!`);
    }
  }

  contributeToPool(poolId) {
    const pool = this.groupPools.find(p => p.id === poolId);
    if (!pool) return;

    const qty = 10;
    if (pool.currentQty + qty <= pool.targetQty) {
      pool.currentQty += qty;
      pool.farmersCount += 1;
      this.saveStoredData('kisan_pools', this.groupPools);
      this.render();
      this.showToast(`🌾 Successfully pooled 10 quintals into ${pool.title}! Shared logistics activated.`);
    } else {
      this.showToast('Pool is almost full!');
    }
  }

  reservePreBooking(listingId) {
    const listing = this.listings.find(l => l.id === listingId);
    if (!listing) return;
    this.showToast(`🌾 Pre-booked 20 quintals of ${listing.crop}! Token advance of 10% held in escrow.`);
  }

  bindEvents() {}

  render() {
    const root = document.getElementById('app-root');
    if (!root) return;

    root.innerHTML = `
      <div id="app-shell-container" class="${this.isDeviceFrame ? 'device-mockup-wrapper' : 'w-full min-h-screen bg-slate-50'}">
        <div class="app-mobile-frame ${this.isDeviceFrame ? 'mockup-phone' : 'w-full max-w-2xl mx-auto min-h-screen bg-white shadow-2xl relative pb-28'}">
          
          <!-- Top Navigation Header -->
          <header class="sticky top-0 z-40 bg-emerald-800 text-white shadow-md">
            <div class="px-4 py-3 flex items-center justify-between">
              <div class="flex items-center gap-2.5">
                <div class="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-lime-400 flex items-center justify-center font-black text-slate-900 shadow text-lg">
                  🌾
                </div>
                <div>
                  <h1 class="font-extrabold text-base tracking-tight leading-none">${this.t('appName')}</h1>
                  <span class="text-[10px] text-emerald-200 font-medium">${this.t('appTagline')}</span>
                </div>
              </div>

              <!-- Role Switcher & Lang Dropdown -->
              <div class="flex items-center gap-2">
                <button onclick="kisanApp.setUserRole(kisanApp.userRole === 'farmer' ? 'buyer' : 'farmer')" class="bg-emerald-900/80 hover:bg-emerald-900 text-xs px-2.5 py-1 rounded-full border border-emerald-600/60 font-semibold flex items-center gap-1.5 transition">
                  <span>${this.userRole === 'farmer' ? '👨‍🌾 ' + this.t('farmerMode') : '🏢 ' + this.t('buyerMode')}</span>
                  <span class="text-[9px] bg-amber-400 text-slate-900 font-bold px-1 rounded">Switch</span>
                </button>

                <select onchange="kisanApp.setLanguage(this.value)" class="bg-emerald-900/90 text-white text-xs px-2 py-1 rounded-lg border border-emerald-600 font-medium outline-none cursor-pointer">
                  <option value="en" ${this.currentLang === 'en' ? 'selected' : ''}>🇬🇧 EN</option>
                  <option value="hi" ${this.currentLang === 'hi' ? 'selected' : ''}>🇮🇳 हिन्दी</option>
                  <option value="te" ${this.currentLang === 'te' ? 'selected' : ''}>🇮🇳 తెలుగు</option>
                  <option value="ta" ${this.currentLang === 'ta' ? 'selected' : ''}>🇮🇳 தமிழ்</option>
                  <option value="mr" ${this.currentLang === 'mr' ? 'selected' : ''}>🇮🇳 मराठी</option>
                  <option value="pa" ${this.currentLang === 'pa' ? 'selected' : ''}>🇮🇳 ਪੰਜਾਬੀ</option>
                  <option value="kn" ${this.currentLang === 'kn' ? 'selected' : ''}>🇮🇳 ಕನ್ನಡ</option>
                  <option value="bn" ${this.currentLang === 'bn' ? 'selected' : ''}>🇮🇳 বাংলা</option>
                </select>

                <button onclick="kisanApp.toggleDeviceFrame()" title="Toggle Mobile Mockup Frame / Full Width" class="p-1 text-emerald-200 hover:text-white transition text-xs font-mono">
                  ${this.isDeviceFrame ? '📱' : '💻'}
                </button>
              </div>
            </div>

            <!-- Top Horizontal Scroll Nav -->
            <div class="flex items-center gap-2 px-3 py-2 bg-emerald-900/60 overflow-x-auto no-scrollbar text-xs font-medium border-t border-emerald-700/50">
              <button onclick="kisanApp.setActiveTab('marketplace')" class="px-3 py-1.5 rounded-full whitespace-nowrap transition ${this.activeTab === 'marketplace' ? 'bg-amber-400 text-slate-900 font-bold shadow' : 'bg-emerald-800/80 text-emerald-100'}">
                🛒 ${this.t('marketplace')}
              </button>
              <button onclick="kisanApp.setActiveTab('ticker_live')" class="px-3 py-1.5 rounded-full whitespace-nowrap transition ${this.activeTab === 'ticker_live' ? 'bg-amber-400 text-slate-900 font-bold shadow' : 'bg-emerald-800/80 text-emerald-100'}">
                📊 ${this.t('liveMandiTicker')}
              </button>
              <button onclick="kisanApp.setActiveTab('climate_planner')" class="px-3 py-1.5 rounded-full whitespace-nowrap transition ${this.activeTab === 'climate_planner' ? 'bg-amber-400 text-slate-900 font-bold shadow' : 'bg-emerald-800/80 text-emerald-100'}">
                🌍 ${this.t('climatePlanner')}
              </button>
              <button onclick="kisanApp.setActiveTab('better_farmer')" class="px-3 py-1.5 rounded-full whitespace-nowrap transition ${this.activeTab === 'better_farmer' ? 'bg-amber-400 text-slate-900 font-bold shadow' : 'bg-emerald-800/80 text-emerald-100'}">
                🌱 ${this.t('betterFarmer')}
              </button>
              <button onclick="kisanApp.setActiveTab('ml_engine')" class="px-3 py-1.5 rounded-full whitespace-nowrap transition ${this.activeTab === 'ml_engine' ? 'bg-amber-400 text-slate-900 font-bold shadow' : 'bg-emerald-800/80 text-emerald-100'}">
                🤖 ${this.t('mlPriceAI')}
              </button>
              <button onclick="kisanApp.setActiveTab('whatsapp_alerts')" class="px-3 py-1.5 rounded-full whitespace-nowrap transition ${this.activeTab === 'whatsapp_alerts' ? 'bg-amber-400 text-slate-900 font-bold shadow' : 'bg-emerald-800/80 text-emerald-100'}">
                📲 ${this.t('whatsappAlerts')}
              </button>
              <button onclick="kisanApp.setActiveTab('farmer_duels')" class="px-3 py-1.5 rounded-full whitespace-nowrap transition ${this.activeTab === 'farmer_duels' ? 'bg-amber-400 text-slate-900 font-bold shadow' : 'bg-emerald-800/80 text-emerald-100'}">
                ⚔️ ${this.t('farmerDuels')}
              </button>
              <button onclick="kisanApp.setActiveTab('mandi')" class="px-3 py-1.5 rounded-full whitespace-nowrap transition ${this.activeTab === 'mandi' ? 'bg-amber-400 text-slate-900 font-bold shadow' : 'bg-emerald-800/80 text-emerald-100'}">
                📈 ${this.t('mandiPrices')}
              </button>
              <button onclick="kisanApp.setActiveTab('sell_now')" class="px-3 py-1.5 rounded-full whitespace-nowrap transition ${this.activeTab === 'sell_now' ? 'bg-amber-400 text-slate-900 font-bold shadow' : 'bg-emerald-800/80 text-emerald-100'}">
                🎙️ ${this.t('voiceSellNow')}
              </button>
              <button onclick="kisanApp.setActiveTab('scan_produce')" class="px-3 py-1.5 rounded-full whitespace-nowrap transition ${this.activeTab === 'scan_produce' ? 'bg-amber-400 text-slate-900 font-bold shadow' : 'bg-emerald-800/80 text-emerald-100'}">
                📷 ${this.t('aiProduceScan')}
              </button>
              <button onclick="kisanApp.setActiveTab('demands')" class="px-3 py-1.5 rounded-full whitespace-nowrap transition ${this.activeTab === 'demands' ? 'bg-amber-400 text-slate-900 font-bold shadow' : 'bg-emerald-800/80 text-emerald-100'}">
                📋 ${this.t('buyerDemands')}
              </button>
              <button onclick="kisanApp.setActiveTab('groups')" class="px-3 py-1.5 rounded-full whitespace-nowrap transition ${this.activeTab === 'groups' ? 'bg-amber-400 text-slate-900 font-bold shadow' : 'bg-emerald-800/80 text-emerald-100'}">
                🤝 ${this.t('groupSelling')}
              </button>
              <button onclick="kisanApp.setActiveTab('logistics')" class="px-3 py-1.5 rounded-full whitespace-nowrap transition ${this.activeTab === 'logistics' ? 'bg-amber-400 text-slate-900 font-bold shadow' : 'bg-emerald-800/80 text-emerald-100'}">
                🚚 ${this.t('logistics')}
              </button>
              <button onclick="kisanApp.setActiveTab('orders')" class="px-3 py-1.5 rounded-full whitespace-nowrap transition ${this.activeTab === 'orders' ? 'bg-amber-400 text-slate-900 font-bold shadow' : 'bg-emerald-800/80 text-emerald-100'}">
                📦 ${this.t('myOrders')}
              </button>
              <button onclick="kisanApp.setActiveTab('earnings')" class="px-3 py-1.5 rounded-full whitespace-nowrap transition ${this.activeTab === 'earnings' ? 'bg-amber-400 text-slate-900 font-bold shadow' : 'bg-emerald-800/80 text-emerald-100'}">
                💰 ${this.t('earnings')}
              </button>
            </div>
          </header>

          <!-- Main Content -->
          <main class="p-4 space-y-4">
            ${this.renderTabContent()}
          </main>

          <!-- Bottom Nav -->
          <nav class="fixed bottom-0 left-0 right-0 max-w-2xl mx-auto bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-2 flex items-center justify-between z-30 shadow-2xl">
            <button onclick="kisanApp.setActiveTab('marketplace')" class="flex flex-col items-center gap-0.5 text-xs ${this.activeTab === 'marketplace' ? 'text-emerald-700 font-bold' : 'text-slate-500'}">
              <span class="text-lg">🛒</span>
              <span>${this.t('navMarket')}</span>
            </button>

            <button onclick="kisanApp.setActiveTab('ticker_live')" class="flex flex-col items-center gap-0.5 text-xs ${this.activeTab === 'ticker_live' ? 'text-emerald-700 font-bold' : 'text-slate-500'}">
              <span class="text-lg">📊</span>
              <span>${this.t('liveMandiTicker')}</span>
            </button>
            
            <button onclick="kisanApp.setActiveTab('climate_planner')" class="flex flex-col items-center gap-0.5 text-xs ${this.activeTab === 'climate_planner' ? 'text-emerald-700 font-bold' : 'text-slate-500'}">
              <span class="text-lg">🌍</span>
              <span>${this.t('navClimate')}</span>
            </button>

            <!-- Center Mic -->
            <button onclick="kisanApp.setActiveTab('sell_now')" class="-mt-6 bg-gradient-to-tr from-emerald-600 to-lime-500 text-white w-14 h-14 rounded-full shadow-xl flex flex-col items-center justify-center border-4 border-white transition hover:scale-105 active:scale-95">
              <span class="text-xl">🎙️</span>
              <span class="text-[9px] font-black tracking-tight uppercase">${this.t('navSell')}</span>
            </button>

            <button onclick="kisanApp.setActiveTab('better_farmer')" class="flex flex-col items-center gap-0.5 text-xs ${this.activeTab === 'better_farmer' ? 'text-emerald-700 font-bold' : 'text-slate-500'}">
              <span class="text-lg">🌱</span>
              <span>${this.t('navGrowth')}</span>
            </button>

            <button onclick="kisanApp.setActiveTab('whatsapp_alerts')" class="flex flex-col items-center gap-0.5 text-xs ${this.activeTab === 'whatsapp_alerts' ? 'text-emerald-700 font-bold' : 'text-slate-500'}">
              <span class="text-lg">📲</span>
              <span>${this.t('navWhatsApp')}</span>
            </button>
          </nav>

          <!-- WhatsApp Chat Simulator Modal -->
          <div id="whatsapp-sim-modal" class="hidden fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
            <div class="bg-[#0b141a] text-white w-full max-w-sm rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
              <div class="bg-[#202c33] px-4 py-3 flex items-center justify-between border-b border-slate-700">
                <div class="flex items-center gap-2">
                  <div class="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-sm">🌾</div>
                  <div>
                    <h4 id="whatsapp-sim-title" class="font-bold text-xs text-slate-100">KisanSetu Alerts</h4>
                    <span class="text-[10px] text-emerald-400">online</span>
                  </div>
                </div>
                <button onclick="kisanApp.closeWhatsAppSimulator()" class="text-slate-400 hover:text-white font-bold text-lg">✕</button>
              </div>

              <!-- Message Window -->
              <div id="whatsapp-sim-messages" class="p-4 overflow-y-auto bg-[#0b141a] bg-opacity-95 space-y-3 min-h-[280px]">
                <!-- Messages rendered here -->
              </div>
            </div>
          </div>

          <!-- Negotiation Chat Modal -->
          <div id="chat-negotiation-modal" class="hidden fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
            <div class="bg-slate-50 w-full max-w-lg rounded-t-3xl sm:rounded-3xl shadow-2xl max-h-[90vh] flex flex-col overflow-hidden animate-slideUp">
              <div class="bg-emerald-800 text-white p-4 flex items-center justify-between">
                <div>
                  <h3 id="chat-header-title" class="font-bold text-base">Direct Negotiation Chat</h3>
                  <p id="chat-header-subtitle" class="text-xs text-emerald-200">100% Escrow Protected</p>
                </div>
                <button onclick="kisanApp.closeChatModal()" class="text-emerald-200 hover:text-white text-xl font-bold p-1">✕</button>
              </div>

              <div id="chat-messages-container" class="flex-1 p-4 overflow-y-auto min-h-[260px] max-h-[360px] bg-slate-100"></div>

              <div class="px-4 py-2 bg-white border-t border-slate-200 flex gap-2 overflow-x-auto no-scrollbar text-xs">
                <button onclick="kisanApp.sendChatMessage('I can confirm prompt dispatch with vehicle ready.', false)" class="bg-slate-100 hover:bg-slate-200 text-slate-700 px-2.5 py-1 rounded-full whitespace-nowrap border">
                  🚚 Ready for dispatch
                </button>
                <button onclick="kisanApp.sendChatMessage('What is the best price for bulk 50 quintals?', false)" class="bg-slate-100 hover:bg-slate-200 text-slate-700 px-2.5 py-1 rounded-full whitespace-nowrap border">
                  💬 Ask bulk discount
                </button>
                <button onclick="kisanApp.sendChatMessage('Offer: ₹2550/qtl for 40 quintals', true, 2550, 40)" class="bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold px-2.5 py-1 rounded-full whitespace-nowrap border border-amber-300">
                  🏷️ Offer ₹2,550/qtl
                </button>
              </div>

              <div class="p-3 bg-white border-t border-slate-200 flex items-center gap-2">
                <input id="chat-input-text" type="text" placeholder="Type price offer or message..." class="flex-1 bg-slate-100 text-slate-800 text-sm px-4 py-2.5 rounded-full border border-slate-300 focus:outline-none focus:border-emerald-500" onkeydown="if(event.key==='Enter') kisanApp.sendChatMessage()" />
                <button onclick="kisanApp.sendChatMessage()" class="bg-emerald-600 hover:bg-emerald-700 text-white w-10 h-10 rounded-full flex items-center justify-center font-bold shadow">
                  ➤
                </button>
              </div>
            </div>
          </div>

        </div>
      </div>
    `;
  }

  // --- Dynamic Tab Renderers ---
  renderTabContent() {
    switch (this.activeTab) {
      case 'marketplace':
        return this.renderMarketplaceTab();
      case 'climate_planner':
        return this.renderClimatePlannerTab();
      case 'better_farmer':
        return this.renderBetterFarmerTab();
      case 'ml_engine':
        return this.renderMLEngineTab();
      case 'whatsapp_alerts':
        return this.renderWhatsAppAlertsTab();
      case 'farmer_duels':
        return this.renderFarmerDuelsTab();
      case 'mandi':
        return this.renderMandiPricesTab();
      case 'sell_now':
        return this.renderSellNowTab();
      case 'scan_produce':
        return this.renderProduceScanTab();
      case 'demands':
        return this.renderBuyerDemandsTab();
      case 'groups':
        return this.renderGroupPoolsTab();
      case 'logistics':
        return this.renderLogisticsTab();
      case 'orders':
        return this.renderOrdersTab();
      case 'earnings':
        return this.renderEarningsTab();
      case 'ticker_live':
        return this.renderLiveTickerTab();
      default:
        return this.renderMarketplaceTab();
    }
  }

  // --- Climate Resilience Planner Tab ---
  renderClimatePlannerTab() {
    const planner = this.climatePlanner;
    const region = planner.selectedRegion;
    const currentCrop = planner.selectedCurrentCrop;
    const risk = planner.analyzeClimateRisk(region, currentCrop);
    const alternatives = planner.getAlternativeCropRecommendations(region, currentCrop);
    const subsidies = planner.subsidies;

    const regionsList = planner.climateProfiles.map(r => r.name);
    const conventionalCrops = ["Paddy (Rice)", "Sugarcane", "Cotton", "Tomato", "Wheat"];

    return `
      <div class="space-y-4">
        <!-- Climate Banner -->
        <div class="bg-gradient-to-r from-emerald-950 via-teal-900 to-cyan-950 text-white rounded-3xl p-5 shadow-xl space-y-2">
          <div class="flex items-center justify-between">
            <span class="bg-emerald-400 text-slate-950 text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider">
              AI Climate Adaptation
            </span>
            <span class="text-xs text-emerald-300 font-bold">Climate-Smart Farming</span>
          </div>
          <h2 class="text-xl font-black">Climate Resilience & Crop Shift Planner</h2>
          <p class="text-xs text-emerald-100">
            Suggests high-profit alternative crops tailored to changing regional climate anomalies (monsoon deficits, heatwaves & groundwater depletion).
          </p>
        </div>

        <!-- Region & Crop Selectors -->
        <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-3">
          <h3 class="font-black text-xs text-slate-800 uppercase tracking-wider">📍 Your Farm Climate Parameters</h3>
          <div class="grid grid-cols-2 gap-3 text-xs">
            <div>
              <label class="block text-[10px] font-bold text-slate-500 mb-1">Agro-Climatic Zone:</label>
              <select onchange="kisanApp.climatePlanner.savePreferences(this.value, kisanApp.climatePlanner.selectedCurrentCrop); kisanApp.render();" class="w-full bg-slate-50 border border-slate-300 rounded-xl p-2 font-bold text-slate-800 text-xs">
                ${regionsList.map(r => `<option value="${r}" ${region === r ? 'selected' : ''}>${r}</option>`).join('')}
              </select>
            </div>

            <div>
              <label class="block text-[10px] font-bold text-slate-500 mb-1">Current Conventional Crop:</label>
              <select onchange="kisanApp.climatePlanner.savePreferences(kisanApp.climatePlanner.selectedRegion, this.value); kisanApp.render();" class="w-full bg-slate-50 border border-slate-300 rounded-xl p-2 font-bold text-slate-800 text-xs">
                ${conventionalCrops.map(c => `<option value="${c}" ${currentCrop === c ? 'selected' : ''}>${c}</option>`).join('')}
              </select>
            </div>
          </div>
        </div>

        <!-- Climate Risk Diagnostic Card -->
        <div class="bg-gradient-to-tr from-rose-950 to-orange-950 text-white rounded-3xl p-5 shadow-lg space-y-3 border border-rose-500/30">
          <div class="flex items-center justify-between">
            <div>
              <span class="text-[10px] uppercase font-bold text-rose-300">Vulnerability Index for ${currentCrop}</span>
              <h3 class="text-xl font-black mt-0.5 text-white">${risk.riskLevel}</h3>
            </div>
            <div class="text-right">
              <span class="text-2xl font-black text-rose-400">${risk.riskScore}</span>
              <span class="text-xs text-rose-200">/100</span>
            </div>
          </div>

          <div class="grid grid-cols-2 gap-2 text-xs pt-1 border-t border-rose-800/60">
            <div class="bg-black/30 p-2 rounded-xl">
              <span class="text-[10px] text-rose-200 block">Rainfall Pattern:</span>
              <strong class="text-[11px] text-slate-100">${risk.projectedRainfallShift}</strong>
            </div>
            <div class="bg-black/30 p-2 rounded-xl">
              <span class="text-[10px] text-rose-200 block">Water Table Impact:</span>
              <strong class="text-[11px] text-slate-100">${risk.groundwaterStatus}</strong>
            </div>
          </div>

          <div class="bg-rose-900/60 border border-rose-500/40 rounded-xl p-2.5 text-xs text-rose-100">
            ${risk.aiAlert}
          </div>
        </div>

        <!-- Recommended Climate-Smart Alternative Crops -->
        <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-3">
          <div class="flex items-center justify-between">
            <div>
              <span class="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full uppercase">High-Yield Alternatives</span>
              <h3 class="text-sm font-black text-slate-800 mt-1">Recommended Climate-Resilient Crops</h3>
            </div>
          </div>

          <div class="space-y-3.5">
            ${alternatives.map(alt => `
              <div class="p-4 rounded-2xl border transition ${
                alt.isTopPick ? 'bg-gradient-to-r from-emerald-50 to-lime-50 border-emerald-400 shadow-sm' : 'bg-slate-50 border-slate-200'
              } space-y-2.5">
                <div class="flex items-start justify-between">
                  <div>
                    <span class="text-[10px] font-bold text-emerald-800 uppercase block">${alt.category}</span>
                    <h4 class="font-black text-sm text-slate-900">${alt.name}</h4>
                  </div>
                  <div class="text-right">
                    <span class="text-xs font-black text-emerald-700 bg-emerald-200/80 px-2 py-0.5 rounded-full block">
                      ${alt.suitabilityScore}% Fit
                    </span>
                    ${alt.hasGovtMSP ? '<span class="text-[9px] text-slate-500 font-bold mt-0.5 block">Govt MSP Protected</span>' : ''}
                  </div>
                </div>

                <div class="grid grid-cols-3 gap-2 text-center text-xs">
                  <div class="bg-white p-2 rounded-xl border border-emerald-200/60">
                    <span class="text-[10px] text-slate-500 block">Water Saved</span>
                    <strong class="text-emerald-700">${alt.waterReductionPct}</strong>
                  </div>
                  <div class="bg-white p-2 rounded-xl border border-emerald-200/60">
                    <span class="text-[10px] text-slate-500 block">Input Cost</span>
                    <strong class="text-emerald-700">${alt.costReductionPct}</strong>
                  </div>
                  <div class="bg-white p-2 rounded-xl border border-emerald-200/60">
                    <span class="text-[10px] text-slate-500 block">Net Profit/Acre</span>
                    <strong class="text-amber-800 font-black">${alt.netProfitPerAcre}</strong>
                  </div>
                </div>

                <p class="text-xs text-slate-600">${alt.description}</p>

                <div class="bg-white/80 p-2.5 rounded-xl border border-slate-200 text-xs space-y-1">
                  <div class="flex items-center justify-between text-[11px]">
                    <span class="text-slate-500">Sowing Window: <strong>${alt.idealSowingWindow}</strong></span>
                    <span class="text-slate-500">Maturity: <strong>${alt.maturityDays}</strong></span>
                  </div>
                  <div class="text-[10px] text-emerald-900 pt-1 border-t border-slate-200 font-medium">
                    🏢 <strong>Buyer Demand Network:</strong> ${alt.buyerDemandNetwork}
                  </div>
                </div>

                <div class="flex items-center gap-2 pt-1">
                  <button onclick="kisanApp.setActiveTab('sell_now'); setTimeout(() => { document.getElementById('sell-crop-name').value='${alt.name.split(' ')[0]}'; document.getElementById('sell-description').value='Climate-Resilient Harvest. ${alt.description}'; }, 150);" class="flex-1 bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2 rounded-xl text-xs text-center shadow">
                    🌾 List Harvest Pre-Booking
                  </button>
                </div>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Government Climate Transition Subsidies -->
        <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-3">
          <div class="flex items-center justify-between">
            <h3 class="font-black text-xs text-slate-800 uppercase tracking-wider">🏛️ Transition Subsidies & Government Grants</h3>
          </div>

          <div class="space-y-2.5">
            ${subsidies.map(sub => `
              <div class="p-3 bg-amber-50/70 border border-amber-200 rounded-2xl text-xs space-y-1">
                <div class="flex items-center justify-between">
                  <h4 class="font-bold text-slate-900">${sub.title}</h4>
                  <span class="text-[10px] text-amber-900 font-bold bg-amber-200 px-2 py-0.5 rounded">${sub.agency}</span>
                </div>
                <p class="text-[11px] text-amber-950 font-medium">💰 ${sub.benefit}</p>
                <div class="flex items-center justify-between pt-1 text-[11px]">
                  <span class="text-slate-500">For: ${sub.applicableCrops.join(', ')}</span>
                  <button onclick="kisanApp.showToast('🏛️ Direct application form opened for ${sub.title}!')" class="text-emerald-700 font-bold underline">
                    ${sub.linkText} ➔
                  </button>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  }

  // --- 1. Better Farmer Diagnostic Assessment & Rewards Wallet Tab ---
  renderBetterFarmerTab() {
    const questions = this.betterFarmerEngine.quizQuestions;
    const vouchers = this.betterFarmerEngine.rewardVouchers;
    const score = this.betterFarmerEngine.userScore;
    const result = this.quizResult;

    return `
      <div class="space-y-4">
        <!-- Banner -->
        <div class="bg-gradient-to-r from-emerald-800 via-teal-800 to-lime-900 text-white rounded-3xl p-5 shadow-lg space-y-2">
          <span class="bg-lime-400 text-slate-950 text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider">
            Diagnostic Health Check & Discounts
          </span>
          <h2 class="text-xl font-black">How to Become a Better Farmer</h2>
          <p class="text-xs text-emerald-100">
            Answer 4 diagnostic questions to receive your farm improvement roadmap and unlock real discount vouchers for seeds, soil tests, and transport!
          </p>

          <div class="flex items-center justify-between pt-2 border-t border-white/20 text-xs">
            <div>
              <span class="text-[10px] text-emerald-200 block">Kisan Score:</span>
              <strong class="text-base text-amber-300 font-black">${score} / 100</strong>
            </div>
            <div class="text-right">
              <span class="text-[10px] text-emerald-200 block">Unlocked Discounts:</span>
              <strong class="text-sm text-lime-300 font-bold">${vouchers.filter(v => v.unlocked).length} Active Vouchers</strong>
            </div>
          </div>
        </div>

        <!-- Diagnostic Questions Accordion/Cards -->
        <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-4">
          <h3 class="font-black text-sm text-slate-800 flex items-center justify-between">
            <span>📝 Farm Diagnostic Questions</span>
            <span class="text-xs text-emerald-700 font-semibold">${Object.keys(this.quizAnswers).length}/${questions.length} Answered</span>
          </h3>

          <div class="space-y-3.5">
            ${questions.map((q, qIdx) => `
              <div class="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2.5">
                <div class="flex items-start gap-2">
                  <span class="w-5 h-5 rounded-full bg-emerald-700 text-white text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                    ${qIdx + 1}
                  </span>
                  <div>
                    <span class="text-[10px] uppercase font-bold text-emerald-800 block">${q.category}</span>
                    <h4 class="font-bold text-xs text-slate-900">${q.question}</h4>
                  </div>
                </div>

                <div class="space-y-1.5 pt-1">
                  ${q.options.map((opt, optIdx) => {
                    const isSelected = this.quizAnswers[q.id] === optIdx;
                    return `
                      <button onclick="kisanApp.recordQuizAnswer('${q.id}', ${optIdx})" class="w-full text-left p-2.5 rounded-xl border text-xs transition flex items-center justify-between ${
                        isSelected ? 'bg-emerald-100/90 border-emerald-500 font-bold text-emerald-950 shadow-sm' : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                      }">
                        <div class="flex items-center gap-2">
                          <span class="w-4 h-4 rounded-full border flex items-center justify-center ${isSelected ? 'border-emerald-600 bg-emerald-600 text-white text-[10px]' : 'border-slate-400'}">
                            ${isSelected ? '✓' : ''}
                          </span>
                          <span>${opt.label}</span>
                        </div>
                        <span class="text-[10px] text-emerald-700 font-semibold shrink-0 ml-2">${opt.potentialGain}</span>
                      </button>
                    `;
                  }).join('')}
                </div>
              </div>
            `).join('')}
          </div>

          <button onclick="kisanApp.submitFarmerAssessment()" class="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-black py-4 rounded-2xl shadow-md transition text-sm btn-farmer-primary ripple-effect flex items-center justify-center gap-2">
            <span class="text-xl">✓</span> ${this.t('submitAssessment')}
          </button>
        </div>

        <!-- Assessment Result & AI Roadmap -->
        ${result ? `
          <div class="bg-emerald-50 border-2 border-emerald-500 rounded-2xl p-4 shadow-md space-y-3">
            <div class="flex items-center justify-between">
              <div>
                <span class="text-[10px] uppercase font-bold text-emerald-800 bg-emerald-200 px-2 py-0.5 rounded-full">Diagnostic Result</span>
                <h3 class="text-base font-black text-slate-900 mt-1">${result.badge}</h3>
              </div>
              <div class="text-right">
                <span class="text-2xl font-black text-emerald-700">${result.score}</span>
                <span class="text-xs text-slate-500">/100</span>
              </div>
            </div>

            <div class="space-y-2">
              <h4 class="font-bold text-xs text-slate-800">💡 Custom Improvement Roadmap for Your Farm:</h4>
              ${result.recommendations.map(rec => `
                <div class="p-2.5 bg-white rounded-xl border border-emerald-200 text-xs space-y-1">
                  <div class="flex items-center justify-between text-emerald-900 font-bold">
                    <span>${rec.category}</span>
                    <span class="text-amber-600 text-[10px]">${rec.impact}</span>
                  </div>
                  <p class="text-slate-600 text-[11px]">${rec.action}</p>
                </div>
              `).join('')}
            </div>
          </div>
        ` : ''}

        <!-- Rewards & Discount Vouchers Wallet -->
        <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-3">
          <div class="flex items-center justify-between">
            <h3 class="font-black text-sm text-slate-800 flex items-center gap-1.5">
              <span>🎁 Kisan Rewards & Discount Wallet</span>
            </h3>
            <span class="text-xs text-slate-500">Score 40+ to unlock</span>
          </div>

          <div class="space-y-2.5">
            ${vouchers.map(v => `
              <div class="p-3 rounded-2xl border transition ${
                v.unlocked ? 'bg-gradient-to-r from-amber-50 to-orange-50 border-amber-300 shadow-sm' : 'bg-slate-50 border-slate-200 opacity-60'
              }">
                <div class="flex items-start justify-between">
                  <div>
                    <span class="text-[9px] uppercase font-bold text-amber-900 block">${v.partner}</span>
                    <h4 class="font-bold text-xs text-slate-900">${v.title}</h4>
                    <p class="text-[10px] text-slate-600 mt-0.5">${v.description}</p>
                  </div>
                  <span class="text-xs font-black text-amber-700 bg-amber-200/80 px-2 py-1 rounded-lg shrink-0 ml-2">
                    ${v.discountValue}
                  </span>
                </div>

                <div class="flex items-center justify-between mt-2 pt-2 border-t border-amber-200/60 text-xs">
                  <span class="text-[10px] font-mono text-slate-500">
                    ${v.unlocked ? `Code: <strong>${v.couponCode}</strong>` : `🔒 Unlock at Score ${v.requiredScore}`}
                  </span>
                  ${v.unlocked ? `
                    <button onclick="kisanApp.redeemRewardVoucher('${v.id}')" class="font-bold px-3 py-1 rounded-xl text-xs shadow transition ${
                      v.isRedeemed ? 'bg-slate-300 text-slate-700 cursor-default' : 'bg-amber-500 hover:bg-amber-600 text-slate-950'
                    }">
                      ${v.isRedeemed ? '✓ Redeemed' : 'Claim Discount'}
                    </button>
                  ` : `
                    <span class="text-[10px] text-slate-400">Score more in Q&A</span>
                  `}
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  }

  // --- 2. Multi-Variable ML Price Prediction & Feedback Loop Tab ---
  renderMLEngineTab() {
    const crops = this.marketEngine.getAllCommodities();
    const res = this.lastMLResult;
    const history = this.mlEngine.historicalFeedbackLog;

    return `
      <div class="space-y-4">
        <!-- Banner -->
        <div class="bg-gradient-to-r from-slate-900 via-indigo-950 to-emerald-950 text-white rounded-3xl p-5 shadow-xl space-y-2">
          <div class="flex items-center justify-between">
            <span class="bg-indigo-500/30 text-indigo-300 text-[10px] font-black px-2.5 py-0.5 rounded-full border border-indigo-400/30 uppercase">
              Machine Learning AI Model
            </span>
            <span class="text-xs text-lime-400 font-mono font-bold">Accuracy: ${res.accuracyScore}</span>
          </div>
          <h2 class="text-xl font-black">Multi-Variable ML Price Prediction</h2>
          <p class="text-xs text-slate-300">
            Learns and predicts market prices by connecting Land characteristics, Weather anomalies, Cultural/Festival surges, and Diesel freight indices with self-correcting feedback.
          </p>
        </div>

        <!-- Interactive ML Input Parameters -->
        <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-3">
          <h3 class="font-black text-xs text-slate-800 uppercase tracking-wider">🎛️ ML Feature Vector Parameters</h3>
          
          <div class="grid grid-cols-2 gap-3 text-xs">
            <div>
              <label class="block text-[10px] font-bold text-slate-500 mb-1">Crop Commodity:</label>
              <select onchange="kisanApp.mlCrop = this.value; kisanApp.runMLPricePrediction();" class="w-full bg-slate-50 border border-slate-300 rounded-xl p-2 font-bold text-slate-800 text-xs">
                ${crops.map(c => `<option value="${c}" ${this.mlCrop === c ? 'selected' : ''}>${c}</option>`).join('')}
              </select>
            </div>

            <div>
              <label class="block text-[10px] font-bold text-slate-500 mb-1">Soil / Land Type:</label>
              <select onchange="kisanApp.mlSoil = this.value; kisanApp.runMLPricePrediction();" class="w-full bg-slate-50 border border-slate-300 rounded-xl p-2 font-bold text-slate-800 text-xs">
                <option value="Black Loamy" ${this.mlSoil === 'Black Loamy' ? 'selected' : ''}>Black Loamy (High Retain)</option>
                <option value="Alluvial" ${this.mlSoil === 'Alluvial' ? 'selected' : ''}>Alluvial (River Basin)</option>
                <option value="Red Sandy" ${this.mlSoil === 'Red Sandy' ? 'selected' : ''}>Red Sandy Loam</option>
              </select>
            </div>
          </div>

          <div class="grid grid-cols-2 gap-3 text-xs">
            <div>
              <label class="block text-[10px] font-bold text-slate-500 mb-1">Weather / Climate Risk:</label>
              <select onchange="kisanApp.mlWeather = this.value; kisanApp.runMLPricePrediction();" class="w-full bg-slate-50 border border-slate-300 rounded-xl p-2 font-bold text-slate-800 text-xs">
                <option value="Excess Rain" ${this.mlWeather === 'Excess Rain' ? 'selected' : ''}>🌧️ Excess Unseasonal Rain (+14% supply deficit)</option>
                <option value="Normal" ${this.mlWeather === 'Normal' ? 'selected' : ''}>☀️ Normal Weather</option>
                <option value="Severe Drought" ${this.mlWeather === 'Severe Drought' ? 'selected' : ''}>🏜️ Severe Drought Deficit</option>
                <option value="Heatwave" ${this.mlWeather === 'Heatwave' ? 'selected' : ''}>🔥 Heatwave (Quick Perish)</option>
              </select>
            </div>

            <div>
              <label class="block text-[10px] font-bold text-slate-500 mb-1">Cultural / Festival Surge:</label>
              <select onchange="kisanApp.mlFestival = this.value; kisanApp.runMLPricePrediction();" class="w-full bg-slate-50 border border-slate-300 rounded-xl p-2 font-bold text-slate-800 text-xs">
                <option value="Diwali / Wedding Surge" ${this.mlFestival === 'Diwali / Wedding Surge' ? 'selected' : ''}>🎉 Diwali & Wedding Season (+15% demand)</option>
                <option value="Pongal / Sankranti" ${this.mlFestival === 'Pongal / Sankranti' ? 'selected' : ''}>🌾 Pongal / Sankranti Rush</option>
                <option value="Off-Season" ${this.mlFestival === 'Off-Season' ? 'selected' : ''}>Standard Off-Season</option>
              </select>
            </div>
          </div>
        </div>

        <!-- ML Output Card -->
        <div class="bg-gradient-to-tr from-emerald-800 to-teal-900 text-white rounded-3xl p-5 shadow-lg space-y-3">
          <div class="flex items-center justify-between">
            <div>
              <span class="text-[10px] text-emerald-200 uppercase font-bold">Predicted Mandi Price Target</span>
              <h3 class="text-2xl font-black mt-0.5">₹${res.predictedPrice.toLocaleString('en-IN')}<span class="text-xs font-normal text-emerald-200"> / quintal</span></h3>
            </div>
            <div class="text-right">
              <span class="text-xs font-bold text-amber-300 block">Expected Shift:</span>
              <strong class="text-base font-black ${parseFloat(res.priceDeltaPct) >= 0 ? 'text-lime-300' : 'text-rose-300'}">
                ${parseFloat(res.priceDeltaPct) >= 0 ? '+' : ''}${res.priceDeltaPct}%
              </strong>
            </div>
          </div>

          <div class="grid grid-cols-2 gap-2 pt-2 border-t border-white/20 text-xs">
            <div>
              <span class="text-emerald-200 text-[10px] block">95% Confidence Interval:</span>
              <strong class="text-xs font-mono">${res.confidenceInterval}</strong>
            </div>
            <div>
              <span class="text-emerald-200 text-[10px] block">Current Benchmark:</span>
              <strong class="text-xs font-mono">₹${res.basePrice}/qtl</strong>
            </div>
          </div>

          <div class="bg-black/30 backdrop-blur rounded-2xl p-3 text-xs space-y-1.5 border border-white/10">
            <span class="text-lime-300 font-bold block">💡 Multi-Vector Weight Contribution:</span>
            <div class="grid grid-cols-2 gap-1 text-[11px] text-slate-200">
              <div>• Land / Soil: <strong>${res.factors.landImpact}</strong></div>
              <div>• Weather Risk: <strong>${res.factors.weatherImpact}</strong></div>
              <div>• Festival Surge: <strong>${res.factors.festivalImpact}</strong></div>
              <div>• Transport Diesel: <strong>${res.factors.logisticsImpact}</strong></div>
            </div>
          </div>

          <p class="text-xs text-emerald-100">${res.aiRecommendation}</p>
        </div>

        <!-- Active Self-Correction Loop ("Predict ➔ Record ➔ Re-correct") -->
        <div class="bg-white rounded-2xl border-2 border-indigo-500 p-4 shadow-sm space-y-3">
          <div class="flex items-center justify-between">
            <div>
              <span class="text-[10px] font-bold text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded-full uppercase">Active Learning Feedback</span>
              <h3 class="text-xs font-black text-slate-900 mt-1">Predict ➔ Record ➔ Re-correct Loop</h3>
            </div>
            <button onclick="kisanApp.recalibrateMLEngine()" class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-3 py-1.5 rounded-xl shadow transition">
              ${this.t('recalibrateBtn')}
            </button>
          </div>

          <div class="space-y-2">
            ${history.map(item => `
              <div class="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-slate-800">${item.crop} (${item.date})</span>
                  <span class="text-[10px] font-bold text-emerald-700">Residual Error: ${item.errorPct}</span>
                </div>
                <div class="flex items-center justify-between text-[11px] text-slate-600">
                  <span>Actual: <strong>₹${item.actualMandi}</strong></span>
                  <span>Initial: <del>₹${item.initialPredicted}</del></span>
                  <span>Recalibrated: <strong class="text-emerald-700">₹${item.recalibratedPredicted}</strong></span>
                </div>
                <span class="text-[10px] text-indigo-900 block bg-indigo-50 px-2 py-0.5 rounded">Learned: ${item.factors}</span>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  }

  // --- 3. WhatsApp Direct Bridge & Push Alerts Tab ---
  renderWhatsAppAlertsTab() {
    const phone = this.waBridge.subscribedNumber;
    const enabled = this.waBridge.alertsEnabled;

    return `
      <div class="space-y-4">
        <!-- Banner -->
        <div class="bg-gradient-to-r from-emerald-700 via-teal-800 to-slate-900 text-white rounded-3xl p-5 shadow-lg space-y-2">
          <div class="flex items-center gap-2">
            <span class="text-2xl">📲</span>
            <span class="bg-lime-400 text-slate-950 text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase">
              Zero App Friction
            </span>
          </div>
          <h2 class="text-xl font-black">WhatsApp Market Bridge & Push Alerts</h2>
          <p class="text-xs text-emerald-100">
            Farmers use WhatsApp every day. Receive morning mandi rate broadcasts, instant buyer inquiries with 1-tap trade approval buttons, and weather alerts directly in your WhatsApp.
          </p>
        </div>

        <!-- Phone Number & Preferences -->
        <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-3">
          <h3 class="font-black text-xs text-slate-800 uppercase tracking-wider">⚙️ WhatsApp Alert Settings</h3>
          
          <div>
            <label class="block text-[11px] font-bold text-slate-600 mb-1">Your WhatsApp Mobile Number:</label>
            <input id="wa-phone-input" type="tel" value="${phone}" class="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-800 focus:outline-none focus:border-emerald-500" />
          </div>

          <div class="flex items-center justify-between text-xs pt-1">
            <span class="font-bold text-slate-700">Daily Morning Mandi Rates:</span>
            <input id="wa-toggle-daily" type="checkbox" ${enabled ? 'checked' : ''} class="w-4 h-4 text-emerald-600 rounded" />
          </div>

          <div class="flex items-center justify-between text-xs">
            <span class="font-bold text-slate-700">Instant Buyer Offer Alerts:</span>
            <input type="checkbox" checked class="w-4 h-4 text-emerald-600 rounded" />
          </div>
        </div>

        <!-- Action Simulator Buttons -->
        <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-3">
          <h3 class="font-black text-xs text-slate-800 uppercase tracking-wider">⚡ Test WhatsApp Integration</h3>
          <p class="text-xs text-slate-600">Simulate or send real WhatsApp alerts to experience the farmer workflow.</p>

          <div class="grid grid-cols-1 gap-2.5">
            <button onclick="kisanApp.openWhatsAppSimulator('daily_mandi')" class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-xl text-xs shadow transition flex items-center justify-center gap-2">
              <span>📱 Open Simulated WhatsApp Mandi Broadcast</span>
            </button>

            <button onclick="kisanApp.openWhatsAppSimulator('buyer_offer')" class="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-3 rounded-xl text-xs shadow transition flex items-center justify-center gap-2">
              <span>🔔 Open Simulated WhatsApp Buyer Offer with 1-Click Approval</span>
            </button>

            <button onclick="kisanApp.sendRealWhatsAppAlert('daily_mandi')" class="w-full bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold py-2.5 rounded-xl text-xs border transition flex items-center justify-center gap-2">
              <span>💬 Launch Real WhatsApp Message (wa.me) ➔</span>
            </button>
          </div>
        </div>
      </div>
    `;
  }

  // --- 4. Farmer Peer Pairing & Duels Leaderboard Tab ---
  renderFarmerDuelsTab() {
    const peers = this.duelsEngine.findSimilarPeers();
    const activeDuel = this.duelsEngine.getDuelComparison(this.duelsEngine.activeDuelOpponentId);
    const leaderboard = this.duelsEngine.leaderboard;

    return `
      <div class="space-y-4">
        <!-- Banner -->
        <div class="bg-gradient-to-r from-amber-600 via-orange-700 to-red-800 text-white rounded-3xl p-5 shadow-lg space-y-2">
          <span class="bg-amber-300 text-slate-950 text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase">
            Friendly Peer Gamification
          </span>
          <h2 class="text-xl font-black">Farmer Duels & Leaderboard</h2>
          <p class="text-xs text-amber-100">
            You are matched with neighbor farmers who cultivate similar acreage and equipment. Compare yield, produce quality, and price realization to see who is the best farmer!
          </p>
        </div>

        <!-- Head-to-Head Duel Arena -->
        <div class="bg-white rounded-2xl border-2 border-amber-500 p-4 shadow-md space-y-3.5">
          <div class="flex items-center justify-between border-b pb-2.5">
            <div class="text-center flex-1">
              <span class="text-2xl block">👨‍🌾</span>
              <h4 class="font-black text-xs text-slate-900 mt-1">${activeDuel.user.name}</h4>
              <span class="text-[10px] text-slate-500">${activeDuel.user.landAcres} Acres • ${activeDuel.user.crop}</span>
            </div>

            <div class="text-center px-3">
              <span class="w-8 h-8 rounded-full bg-amber-500 text-slate-950 font-black text-xs flex items-center justify-center shadow">VS</span>
            </div>

            <div class="text-center flex-1">
              <span class="text-2xl block">${activeDuel.peer.avatar}</span>
              <h4 class="font-black text-xs text-slate-900 mt-1">${activeDuel.peer.name}</h4>
              <span class="text-[10px] text-slate-500">${activeDuel.peer.landAcres} Acres • ${activeDuel.peer.location}</span>
            </div>
          </div>

          <!-- Metrics Table -->
          <div class="space-y-2 text-xs">
            ${activeDuel.metrics.map(m => `
              <div class="p-2.5 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <div class="text-center font-bold text-[11px] text-slate-600">${m.title}</div>
                <div class="flex items-center justify-between font-mono font-bold">
                  <span class="${m.winner === 'me' ? 'text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded' : 'text-slate-700'}">${m.myVal}</span>
                  <span class="text-[10px] font-sans text-slate-400 font-normal">Diff: ${m.diff}</span>
                  <span class="${m.winner === 'peer' ? 'text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded' : 'text-slate-700'}">${m.peerVal}</span>
                </div>
              </div>
            `).join('')}
          </div>

          <div class="bg-amber-50 border border-amber-200 rounded-xl p-3 text-center text-xs font-bold text-amber-900">
            ${activeDuel.verdict}
          </div>
        </div>

        <!-- Matched Peer Farmers -->
        <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-2.5">
          <h3 class="font-bold text-xs text-slate-700 uppercase tracking-wider">🌾 Similar Peer Farmers in Your District:</h3>
          <div class="space-y-2">
            ${peers.map(p => `
              <div class="p-2.5 bg-slate-50 hover:bg-amber-50 border rounded-xl flex items-center justify-between text-xs transition">
                <div>
                  <div class="font-bold text-slate-900 flex items-center gap-1">
                    <span>${p.avatar} ${p.name}</span>
                    <span class="text-[10px] text-emerald-700 font-bold bg-emerald-100 px-1.5 py-0.2 rounded">${p.compatibilityScore}% Match</span>
                  </div>
                  <span class="text-[10px] text-slate-500">${p.location} • ${p.landAcres} Acres</span>
                </div>
                <button onclick="kisanApp.duelsEngine.activeDuelOpponentId = '${p.id}'; kisanApp.render();" class="bg-amber-400 hover:bg-amber-500 text-slate-950 font-bold px-3 py-1 rounded-lg text-xs shadow">
                  Duel ⚔️
                </button>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Monthly Leaderboard -->
        <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-2.5">
          <h3 class="font-bold text-xs text-slate-700 uppercase tracking-wider">🏆 District Monthly Leaderboard</h3>
          <div class="space-y-1.5">
            ${leaderboard.map(row => `
              <div class="p-2.5 rounded-xl border flex items-center justify-between text-xs ${
                row.name.includes('(You)') ? 'bg-emerald-50 border-emerald-400 font-bold' : 'bg-white border-slate-100'
              }">
                <div class="flex items-center gap-2">
                  <span class="w-5 h-5 rounded-full flex items-center justify-center font-bold text-[11px] ${
                    row.rank === 1 ? 'bg-amber-400 text-slate-900' : 'bg-slate-200 text-slate-700'
                  }">${row.rank}</span>
                  <div>
                    <span class="text-slate-900">${row.name}</span>
                    <span class="text-[10px] text-slate-500 block">${row.district}</span>
                  </div>
                </div>
                <div class="text-right">
                  <span class="text-emerald-700 font-bold">${row.powerScore} pts</span>
                  <span class="text-[9px] text-slate-400 block">${row.rewardBadge}</span>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  }

  // --- Other Existing Tabs (Marketplace, Mandi, Sell Now, Scan, Demands, Logistics, Orders, Earnings) ---
  renderMarketplaceTab() {
    const filtered = this.listings.filter(item => {
      const matchCrop = this.selectedCropFilter === 'All' || item.crop.toLowerCase().includes(this.selectedCropFilter.toLowerCase());
      const matchSearch = !this.searchQuery || item.crop.toLowerCase().includes(this.searchQuery.toLowerCase()) || item.location.toLowerCase().includes(this.searchQuery.toLowerCase()) || item.farmerName.toLowerCase().includes(this.searchQuery.toLowerCase());
      return matchCrop && matchSearch;
    });

    const cropChips = ["All", "Tomato", "Onion", "Wheat", "Paddy (Rice)", "Red Chilli", "Potato"];

    return `
      <div class="space-y-4">
        <!-- Top AI Alert Banner -->
        <div class="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-300 rounded-2xl p-3.5 flex items-center justify-between shadow-sm">
          <div class="flex items-center gap-2.5">
            <span class="text-2xl animate-pulse">🔥</span>
            <div>
              <h4 class="font-bold text-xs text-amber-950">${this.t('highDemandCrop')}</h4>
              <p class="text-[11px] text-amber-800">Tomato (+14%), Onion (+8%) & Basmati export demand peaking.</p>
            </div>
          </div>
          <button onclick="kisanApp.setActiveTab('mandi')" class="text-xs bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-3 py-1.5 rounded-xl shadow-sm transition">
            Check Mandis
          </button>
        </div>

        <!-- Search & Filter Controls -->
        <div class="space-y-2">
          <div class="relative">
            <input type="text" placeholder="${this.t('searchPlaceholder')}" value="${this.searchQuery}" oninput="kisanApp.searchQuery = this.value; kisanApp.render();" class="w-full bg-white border border-slate-300 text-slate-800 text-xs pl-9 pr-4 py-2.5 rounded-xl shadow-sm focus:outline-none focus:border-emerald-500" />
            <span class="absolute left-3 top-2.5 text-slate-400">🔍</span>
          </div>

          <div class="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
            ${cropChips.map(c => `
              <button onclick="kisanApp.selectedCropFilter = '${c}'; kisanApp.render();" class="text-xs px-3 py-1 rounded-full whitespace-nowrap font-medium transition ${
                this.selectedCropFilter === c ? 'bg-emerald-700 text-white shadow' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }">
                ${c}
              </button>
            `).join('')}
          </div>
        </div>

        <!-- Listings Grid -->
        <div class="space-y-3.5">
          ${filtered.length === 0 ? `
            <div class="bg-white rounded-2xl p-8 text-center text-slate-500 border">
              <p class="text-3xl mb-2">🌾</p>
              <p class="font-bold text-sm">No produce listings found matching criteria.</p>
              <button onclick="kisanApp.selectedCropFilter='All'; kisanApp.searchQuery=''; kisanApp.render();" class="mt-3 text-xs text-emerald-700 font-bold underline">Reset Filters</button>
            </div>
          ` : filtered.map(item => `
            <div class="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition">
              <div class="relative h-36 bg-slate-800">
                <img src="${item.photos[0]}" alt="${item.crop}" class="w-full h-full object-cover opacity-90" />
                <div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-black/30"></div>
                
                <div class="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                  <span class="bg-emerald-600/90 backdrop-blur text-white text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                    ✓ ${item.qualityGrade} (${item.qualityScore}/100)
                  </span>
                  ${item.organicCertified ? '<span class="bg-lime-500 text-slate-900 text-[10px] font-black px-1.5 py-0.5 rounded-full">ORGANIC</span>' : ''}
                </div>

                <div class="absolute top-2.5 right-2.5 bg-black/60 backdrop-blur text-white text-[10px] font-medium px-2 py-0.5 rounded-full">
                  📍 ${item.distanceKm} km away
                </div>

                <div class="absolute bottom-2.5 left-3 right-3 flex items-end justify-between text-white">
                  <div>
                    <span class="text-xs text-emerald-300 font-medium">${item.variety}</span>
                    <h3 class="text-lg font-black leading-none">${item.crop}</h3>
                  </div>
                  <div class="text-right">
                    <span class="text-xs text-slate-300 block leading-tight">Asking Price:</span>
                    <span class="text-xl font-black text-amber-300">₹${item.pricePerUnit.toLocaleString('en-IN')}<span class="text-xs text-white font-normal"> / ${item.unit}</span></span>
                  </div>
                </div>
              </div>

              <div class="p-3.5 space-y-2.5">
                <div class="grid grid-cols-3 gap-2 text-center text-xs">
                  <div class="bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                    <span class="text-[10px] text-slate-500 block">Available Qty</span>
                    <strong class="text-slate-800">${item.quantity} ${item.unit}</strong>
                  </div>
                  <div class="bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                    <span class="text-[10px] text-slate-500 block">Moisture</span>
                    <strong class="text-slate-800">${item.moistureContent}</strong>
                  </div>
                  <div class="bg-emerald-50 p-1.5 rounded-lg border border-emerald-100">
                    <span class="text-[10px] text-emerald-700 block">Mandi Spread</span>
                    <strong class="text-emerald-800 font-bold">${item.priceAdvantage}</strong>
                  </div>
                </div>

                <p class="text-xs text-slate-600 line-clamp-2">${item.description}</p>

                <div class="flex items-center justify-between border-t pt-2.5 text-xs">
                  <div class="flex items-center gap-2">
                    <div class="w-7 h-7 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-xs">
                      ${item.farmerName.charAt(0)}
                    </div>
                    <div>
                      <div class="font-bold text-slate-800 flex items-center gap-1">
                        ${item.farmerName}
                        <span class="text-amber-500">★ ${item.trustScore}</span>
                      </div>
                      <span class="text-[10px] text-slate-500">${item.location} • ${item.dealsCompleted} deals</span>
                    </div>
                  </div>

                  <div class="flex items-center gap-1.5">
                    <button onclick="kisanApp.openChatModal('${item.id}')" class="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm px-4 py-2.5 rounded-xl shadow-sm flex items-center gap-1.5 transition btn-farmer-primary ripple-effect">
                      <span class="text-lg">💬</span> <span>${this.t('chatWithFarmer')}</span>
                    </button>
                  </div>
                </div>

                ${item.isPreBooking ? `
                  <div class="bg-amber-50 border border-amber-200 rounded-xl p-2 flex items-center justify-between text-xs text-amber-900">
                    <span>🌾 <strong>Pre-Harvest Booking</strong> (Harvest: ${item.harvestDate})</span>
                    <button onclick="kisanApp.reservePreBooking('${item.id}')" class="bg-amber-500 text-slate-950 font-bold px-2.5 py-1 rounded-lg text-[11px] shadow">
                      Lock Token (10%)
                    </button>
                  </div>
                ` : ''}
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  // Mandi Prices & Arbitrage
  renderMandiPricesTab() {
    const crops = this.marketEngine.getAllCommodities();
    const cropData = this.marketEngine.getCropPriceAcrossMandis(this.selectedMandiCrop);
    const forecastData = this.marketEngine.generate7DayForecast(this.selectedMandiCrop);
    const arbitrageData = this.marketEngine.calculateBestMandiArbitrage(this.selectedMandiCrop, this.arbitrageQty, this.arbitrageRate);

    return `
      <div class="space-y-4">
        <div class="bg-gradient-to-r from-emerald-800 to-teal-800 text-white rounded-2xl p-4 shadow-md">
          <span class="text-[10px] uppercase tracking-wider text-emerald-200 font-bold">Government APMC & Real-Time Discovery</span>
          <h2 class="text-lg font-black mt-0.5">Live Mandi Prices & AI Intelligence</h2>
          <p class="text-xs text-emerald-100 mt-1">Discover live market corridors, calculate net profit after diesel freight, and check 7-day price forecasts.</p>
          
          <div class="mt-3 flex items-center gap-2">
            <span class="text-xs font-semibold">Select Crop:</span>
            <select onchange="kisanApp.selectedMandiCrop = this.value; kisanApp.render();" class="bg-white text-slate-900 text-xs font-bold px-3 py-1.5 rounded-xl outline-none shadow cursor-pointer">
              ${crops.map(c => `<option value="${c}" ${this.selectedMandiCrop === c ? 'selected' : ''}>${c}</option>`).join('')}
            </select>
          </div>
        </div>

        <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-3">
          <div class="flex items-center justify-between">
            <div>
              <span class="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">AI Price Intelligence</span>
              <h3 class="text-sm font-black text-slate-800 mt-1">7-Day Price Forecast for ${this.selectedMandiCrop}</h3>
            </div>
            <div class="text-right">
              <span class="text-xs font-black ${forecastData.trend === 'up' ? 'text-emerald-600' : 'text-rose-600'}">
                ${forecastData.trend === 'up' ? '📈 Bullish' : '📉 Bearish'} (${forecastData.changePct})
              </span>
            </div>
          </div>

          <div class="bg-slate-900 rounded-xl p-3 text-white">
            <div class="flex items-end justify-between h-28 gap-1.5 pt-4">
              ${forecastData.forecast.map((f, idx) => {
                const heightPct = Math.min(100, Math.max(30, ((f.price - forecastData.basePrice * 0.8) / (forecastData.basePrice * 0.5)) * 100));
                return `
                  <div class="flex-1 flex flex-col items-center gap-1 h-full justify-end">
                    <span class="text-[9px] font-bold text-amber-300">₹${f.price}</span>
                    <div class="w-full bg-gradient-to-t from-emerald-600 to-lime-400 rounded-t-sm" style="height: ${heightPct}%"></div>
                    <span class="text-[8px] text-slate-400 truncate w-full text-center">${f.day.replace('Day +', 'D+')}</span>
                  </div>
                `;
              }).join('')}
            </div>
          </div>

          <div class="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-900 flex items-start gap-2">
            <span class="text-base">💡</span>
            <div><strong>Kisan AI Advisory:</strong> ${forecastData.aiAdvice}</div>
          </div>
        </div>

        <div class="bg-white rounded-2xl border-2 border-emerald-500 p-4 shadow-md space-y-3">
          <div>
            <span class="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full uppercase">Profit Maximizer</span>
            <h3 class="text-sm font-black text-slate-800 mt-0.5">Best Mandi Arbitrage Calculator</h3>
          </div>
          <p class="text-xs text-slate-600">Calculates real net profit by subtracting diesel freight & APMC handling from each market rate.</p>

          <div class="grid grid-cols-2 gap-2 text-xs">
            <div class="bg-slate-50 p-2 rounded-xl border border-slate-200">
              <label class="block text-slate-500 text-[10px] font-semibold">Quantity to Sell:</label>
              <input type="number" value="${this.arbitrageQty}" onchange="kisanApp.arbitrageQty = parseFloat(this.value)||10; kisanApp.render();" class="w-full font-bold text-sm bg-transparent outline-none text-slate-800" />
              <span class="text-[10px] text-slate-400">Quintals</span>
            </div>
            <div class="bg-slate-50 p-2 rounded-xl border border-slate-200">
              <label class="block text-slate-500 text-[10px] font-semibold">Freight Rate:</label>
              <input type="number" value="${this.arbitrageRate}" onchange="kisanApp.arbitrageRate = parseFloat(this.value)||20; kisanApp.render();" class="w-full font-bold text-sm bg-transparent outline-none text-slate-800" />
              <span class="text-[10px] text-slate-400">₹ per km (Tata Ace/Truck)</span>
            </div>
          </div>

          <div class="space-y-2">
            ${arbitrageData.map((item, rank) => `
              <div class="p-3 rounded-xl border transition ${
                item.isRecommended && rank === 0 ? 'bg-emerald-50/90 border-emerald-500 shadow-sm' : 'bg-slate-50 border-slate-200'
              }">
                <div class="flex items-center justify-between text-xs">
                  <div>
                    <span class="font-bold text-slate-900">${rank + 1}. ${item.mandiName} (${item.state})</span>
                    <span class="text-[11px] text-slate-500 block">📍 ${item.distanceKm} km | Freight: ₹${item.transportCost.toLocaleString('en-IN')}</span>
                  </div>
                  <div class="text-right">
                    <span class="text-xs text-slate-500 block">Net In-Hand:</span>
                    <strong class="text-sm font-black ${item.isRecommended ? 'text-emerald-700' : 'text-slate-800'}">
                      ₹${item.netProfit.toLocaleString('en-IN')}
                    </strong>
                    <span class="text-[10px] text-slate-600 block">(₹${item.netProfitPerQuintal}/qtl)</span>
                  </div>
                </div>

                ${item.profitDiffTotal > 0 && !item.isLocalBase ? `
                  <div class="mt-2 text-[11px] font-bold text-emerald-800 bg-emerald-100/80 px-2.5 py-1 rounded-lg flex items-center justify-between">
                    <span>✨ Extra Profit vs Local Mandi:</span>
                    <span>+₹${item.profitDiffTotal.toLocaleString('en-IN')}</span>
                  </div>
                ` : ''}
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  }

  // Sell Now Tab
  renderSellNowTab() {
    const presets = this.voiceAI.getPresetVoicePrompts();

    return `
      <div class="space-y-4">
        <div class="bg-gradient-to-tr from-emerald-700 via-teal-800 to-slate-900 text-white rounded-3xl p-6 shadow-xl text-center space-y-3 relative overflow-hidden">
          <div class="absolute -right-6 -bottom-6 text-8xl opacity-10">🎙️</div>
          <span class="inline-block bg-lime-400 text-slate-950 font-black text-[10px] px-3 py-1 rounded-full uppercase tracking-wider shadow">
            1-Tap AI Voice Listing
          </span>
          <h2 class="text-xl font-black">Speak & Sell Your Produce</h2>
          <p class="text-xs text-emerald-100 max-w-sm mx-auto">
            ${this.t('voiceExample')}
          </p>

          <div class="pt-2">
            <button onclick="kisanApp.handleVoiceStart()" class="w-20 h-20 mx-auto rounded-full bg-gradient-to-tr from-lime-400 to-emerald-400 text-slate-950 text-3xl font-black flex items-center justify-center shadow-2xl transition hover:scale-105 active:scale-95 border-4 border-white/40">
              🎙️
            </button>
            <span id="voice-status-text" class="block text-xs font-bold text-emerald-200 mt-2">
              ${this.t('startVoiceBtn')}
            </span>
          </div>

          <div id="voice-listening-card" class="hidden bg-black/40 backdrop-blur rounded-2xl p-3 border border-white/20 text-xs">
            <div class="flex items-center justify-center gap-1.5 mb-2">
              <div class="w-2 h-2 bg-rose-500 rounded-full animate-ping"></div>
              <span class="font-bold text-lime-300">Listening to your voice...</span>
            </div>
            <div id="voice-transcript-output" class="italic text-white/90 text-sm">"..."</div>
            <button onclick="kisanApp.handleVoiceStop()" class="mt-3 bg-amber-400 text-slate-950 font-bold px-4 py-1.5 rounded-full text-xs shadow">
              ✓ Done Speaking (Process)
            </button>
          </div>
        </div>

        <div id="voice-presets-container" class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-2.5">
          <h3 class="font-bold text-xs text-slate-700 uppercase tracking-wider">
            ⚡ Quick Voice Simulation (Try Instant Spoken Prompts)
          </h3>
          <div class="grid grid-cols-1 gap-2">
            ${presets.map(p => `
              <button onclick="kisanApp.processVoiceTranscript('${p.text}')" class="text-left bg-slate-50 hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 p-2.5 rounded-xl transition flex items-center justify-between group">
                <div>
                  <span class="text-[10px] font-bold text-slate-500 block">${p.label}</span>
                  <span class="text-xs text-slate-800 group-hover:text-emerald-900 font-medium">"${p.caption}"</span>
                </div>
                <span class="text-xs text-emerald-600 font-bold opacity-0 group-hover:opacity-100 transition">Test ➔</span>
              </button>
            `).join('')}
          </div>
        </div>

        <div id="voice-parsed-preview" class="hidden"></div>

        <form onsubmit="kisanApp.publishNewListing(event)" class="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-3.5">
          <h3 class="font-black text-sm text-slate-800">${this.t('createListing')}</h3>

          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="block text-[11px] font-bold text-slate-600 mb-1">${this.t('cropName')}</label>
              <select id="sell-crop-name" class="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-emerald-500">
                <option value="Tomato">Tomato (टमाटर)</option>
                <option value="Onion">Onion (कांदा / प्याज)</option>
                <option value="Wheat">Wheat (गेहूं)</option>
                <option value="Paddy (Rice)">Paddy (धान / వరి)</option>
                <option value="Red Chilli">Red Chilli (మిరప / लाल मिर्च)</option>
                <option value="Potato">Potato (आलू)</option>
                <option value="Soybean">Soybean (सोयाबीन)</option>
                <option value="Cotton">Cotton (कपास / పత్తి)</option>
              </select>
            </div>

            <div>
              <label class="block text-[11px] font-bold text-slate-600 mb-1">${this.t('variety')}</label>
              <input id="sell-variety" type="text" value="Hybrid Standard" class="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-emerald-500" />
            </div>
          </div>

          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="block text-[11px] font-bold text-slate-600 mb-1">${this.t('quantity')}</label>
              <input id="sell-quantity" type="number" value="50" class="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold focus:outline-none focus:border-emerald-500" />
            </div>

            <div>
              <label class="block text-[11px] font-bold text-slate-600 mb-1">${this.t('unit')}</label>
              <select id="sell-unit" class="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-emerald-500">
                <option value="quintal">Quintals (100 kg)</option>
                <option value="bags (50kg)">Bags (50 kg)</option>
                <option value="kg">Kilograms</option>
                <option value="crates (25kg)">Crates (25 kg)</option>
              </select>
            </div>
          </div>

          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="block text-[11px] font-bold text-slate-600 mb-1">${this.t('askingPrice')}</label>
              <input id="sell-price" type="number" value="2400" class="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-black text-emerald-700 focus:outline-none focus:border-emerald-500" />
            </div>

            <div>
              <label class="block text-[11px] font-bold text-slate-600 mb-1">${this.t('location')}</label>
              <input id="sell-location" type="text" value="Guntur, AP" class="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-emerald-500" />
            </div>
          </div>

          <div>
            <label class="block text-[11px] font-bold text-slate-600 mb-1">Description / Notes</label>
            <textarea id="sell-description" rows="2" class="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs focus:outline-none focus:border-emerald-500" placeholder="Sun-dried, cleaned, standard packaging..."></textarea>
          </div>

          <div class="flex items-center gap-2">
            <input id="sell-organic" type="checkbox" class="w-4 h-4 text-emerald-600 rounded" />
            <label for="sell-organic" class="text-xs text-slate-700 font-bold">${this.t('organicBadge')}</label>
          </div>

          <button type="submit" class="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-black py-4 rounded-2xl shadow-lg transition text-base flex items-center justify-center gap-2 btn-farmer-primary ripple-effect">
            <span class="text-2xl">🚀</span> ${this.t('postListingBtn')}
          </button>
        </form>
      </div>
    `;
  }

  // Scan produce tab
  renderProduceScanTab() {
    const samples = window.SEED_DATA.sampleProduceScans;

    return `
      <div class="space-y-4">
        <div class="bg-gradient-to-r from-emerald-800 to-slate-900 text-white rounded-3xl p-5 shadow-lg space-y-2">
          <span class="bg-emerald-500/20 text-emerald-300 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase border border-emerald-400/30">
            Computer Vision Produce Grading
          </span>
          <h2 class="text-lg font-black">AI Produce Freshness & Quality Scanner</h2>
          <p class="text-xs text-slate-300">
            Detects skin integrity, moisture levels, blemishes, and computes a certified Grade A/B/C quality score to get up to 20% higher market price.
          </p>
        </div>

        <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-2.5">
          <h3 class="font-bold text-xs text-slate-700 uppercase tracking-wider">Select Sample Produce to Scan:</h3>
          <div class="grid grid-cols-3 gap-2">
            ${samples.map(s => `
              <button onclick="kisanApp.handleProduceScan('${s.id}')" class="group relative rounded-xl overflow-hidden border border-slate-200 hover:border-emerald-500 text-left transition shadow-sm">
                <img src="${s.imageUrl}" alt="${s.cropName}" class="w-full h-20 object-cover group-hover:scale-105 transition" />
                <div class="p-1.5 bg-white">
                  <span class="font-bold text-xs text-slate-800 block truncate">${s.cropName}</span>
                  <span class="text-[9px] text-emerald-700 font-bold block">Tap to Scan 🔍</span>
                </div>
              </button>
            `).join('')}
          </div>
        </div>

        <div class="bg-white rounded-2xl border-2 border-dashed border-emerald-300 p-6 text-center space-y-2">
          <div class="text-3xl">📷</div>
          <h4 class="font-bold text-xs text-slate-800">Scan Custom Crop via Camera or Photo</h4>
          <input type="file" accept="image/*" id="camera-file-input" class="hidden" onchange="
            const file = this.files[0];
            if(file) {
              const r = new FileReader();
              r.onload = (e) => kisanApp.handleProduceScan(null, e.target.result);
              r.readAsDataURL(file);
            }
          " />
          <button id="scan-trigger-btn" onclick="document.getElementById('camera-file-input').click()" class="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm px-6 py-3.5 rounded-2xl shadow-lg transition inline-flex items-center gap-2.5 btn-farmer-primary ripple-effect">
            <span class="text-2xl">📷</span> <span>${this.t('openCameraUpload')}</span>
          </button>
        </div>

        <div id="scan-result-card" class="hidden"></div>
      </div>
    `;
  }

  // Demands Tab
  renderBuyerDemandsTab() {
    return `
      <div class="space-y-4">
        <div class="bg-gradient-to-r from-teal-800 to-cyan-900 text-white rounded-2xl p-4 shadow-md">
          <span class="text-[10px] uppercase font-bold text-cyan-200">B2B Commercial Procurement</span>
          <h2 class="text-lg font-black mt-0.5">${this.t('buyerDemands')}</h2>
          <p class="text-xs text-cyan-100 mt-1">Direct bulk requirements from supermarkets, restaurant chains, and food millers with locked escrow payments.</p>
        </div>

        <div class="space-y-3">
          ${this.demands.map(d => `
            <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-2.5 hover:shadow-md transition">
              <div class="flex items-center justify-between">
                <div>
                  <span class="text-[10px] font-bold text-slate-500 uppercase">${d.buyerType}</span>
                  <h4 class="font-bold text-sm text-slate-900">${d.buyerName} ${d.verified ? '✓' : ''}</h4>
                </div>
                <span class="text-[10px] font-black px-2 py-0.5 rounded-full ${
                  d.urgency === 'Urgent' ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                }">${d.urgency}</span>
              </div>

              <div class="grid grid-cols-3 gap-2 text-center text-xs">
                <div class="bg-slate-50 p-2 rounded-lg border border-slate-100">
                  <span class="text-[10px] text-slate-500 block">Required Crop</span>
                  <strong class="text-slate-800">${d.cropNeeded}</strong>
                </div>
                <div class="bg-slate-50 p-2 rounded-lg border border-slate-100">
                  <span class="text-[10px] text-slate-500 block">Quantity Needed</span>
                  <strong class="text-slate-800">${d.targetQty} ${d.unit}</strong>
                </div>
                <div class="bg-emerald-50 p-2 rounded-lg border border-emerald-100">
                  <span class="text-[10px] text-emerald-700 block">Offered Rate</span>
                  <strong class="text-emerald-800 font-bold">₹${d.offeringPrice.toLocaleString('en-IN')}/qtl</strong>
                </div>
              </div>

              <p class="text-xs text-slate-600">${d.description}</p>

              <div class="flex items-center justify-between text-xs border-t pt-2.5">
                <span class="text-[10px] text-slate-500">📍 ${d.location} • By ${d.deliveryDeadline}</span>
                <button onclick="kisanApp.showToast('🤝 Supply proposal submitted to ${d.buyerName}! They will contact you shortly.')" class="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm px-5 py-2.5 rounded-xl shadow-sm transition btn-farmer-primary ripple-effect flex items-center gap-1.5">
                  <span class="text-lg">🤝</span> ${this.t('supplyThisDemand')}
                </button>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  // Group Pools Tab
  renderGroupPoolsTab() {
    return `
      <div class="space-y-4">
        <div class="bg-gradient-to-r from-lime-800 to-emerald-900 text-white rounded-2xl p-4 shadow-md">
          <span class="text-[10px] uppercase font-bold text-lime-200">FPO & Smallholder Aggregation</span>
          <h2 class="text-lg font-black mt-0.5">${this.t('groupSelling')}</h2>
          <p class="text-xs text-lime-100 mt-1">Combine small harvest lots with neighbor farmers to unlock premium bulk buyer contracts and save 40%+ on transport.</p>
        </div>

        <div class="space-y-3.5">
          ${this.groupPools.map(pool => {
            const pct = Math.round((pool.currentQty / pool.targetQty) * 100);
            return `
              <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-3">
                <div class="flex items-center justify-between">
                  <div>
                    <span class="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">${pool.fpoName}</span>
                    <h3 class="font-bold text-sm text-slate-900 mt-1">${pool.title}</h3>
                  </div>
                  <span class="text-xs font-bold text-amber-600 bg-amber-50 border border-amber-200 px-2 py-1 rounded-lg">
                    ⏳ ${pool.daysLeft} days left
                  </span>
                </div>

                <div class="space-y-1">
                  <div class="flex items-center justify-between text-xs text-slate-700 font-semibold">
                    <span>Pooled: <strong>${pool.currentQty} ${pool.unit}</strong></span>
                    <span>Target: <strong>${pool.targetQty} ${pool.unit}</strong> (${pct}%)</span>
                  </div>
                  <div class="w-full bg-slate-200 h-3 rounded-full overflow-hidden">
                    <div class="bg-gradient-to-r from-emerald-500 to-lime-500 h-full rounded-full transition-all duration-500" style="width: ${pct}%"></div>
                  </div>
                  <span class="text-[10px] text-slate-500">${pool.farmersCount} local farmers participating</span>
                </div>

                <div class="bg-emerald-50 p-2.5 rounded-xl border border-emerald-100 text-xs space-y-1">
                  <div class="flex items-center justify-between">
                    <span class="text-slate-600">Negotiated Bulk Buyer:</span>
                    <strong class="text-slate-900">${pool.negotiatedBuyer}</strong>
                  </div>
                  <div class="flex items-center justify-between">
                    <span class="text-emerald-700 font-bold">Extra Bonus Earning:</span>
                    <strong class="text-emerald-800 font-black">${pool.extraEarningsPerFarmer}</strong>
                  </div>
                </div>

                <button onclick="kisanApp.contributeToPool('${pool.id}')" class="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-3.5 rounded-2xl text-sm shadow transition btn-farmer-primary ripple-effect flex items-center justify-center gap-2">
                  <span class="text-xl">🌾</span> ${this.t('poolQuintals')}
                </button>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  }

  // Logistics Tab
  renderLogisticsTab() {
    return `
      <div class="space-y-4">
        <div class="bg-gradient-to-r from-slate-800 to-emerald-950 text-white rounded-2xl p-4 shadow-md">
          <span class="text-[10px] uppercase font-bold text-emerald-300">Direct Farm-to-Mandi Transport</span>
          <h2 class="text-lg font-black mt-0.5">${this.t('logistics')}</h2>
          <p class="text-xs text-slate-300 mt-1">Book trusted rural truckers with fixed transparent per-km rates and verified transit tracking.</p>
        </div>

        <div class="space-y-3">
          ${this.transporters.map(t => `
            <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-2.5 hover:shadow-md transition">
              <div class="flex items-center justify-between">
                <div>
                  <h4 class="font-bold text-sm text-slate-900">${t.driverName}</h4>
                  <span class="text-xs text-slate-600 font-medium">${t.vehicleType}</span>
                </div>
                <div class="text-right">
                  <span class="text-xs font-black text-emerald-700">₹${t.baseRatePerKm}/km</span>
                  <span class="text-[10px] text-slate-400 block">${t.capacityQuintals} qtl capacity</span>
                </div>
              </div>

              <div class="flex items-center justify-between text-xs text-slate-600 bg-slate-50 p-2 rounded-xl">
                <span>📍 Current: <strong>${t.currentLocation}</strong></span>
                <span class="text-amber-500 font-bold">★ ${t.rating} (${t.tripsDone} trips)</span>
              </div>

              <div class="flex items-center gap-2 pt-1">
                <a href="tel:${t.phone}" class="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold py-3 rounded-xl text-sm text-center border flex items-center justify-center gap-1.5 ripple-effect">
                  <span class="text-lg">📞</span> ${this.t('callDriver')}
                </a>
                <button onclick="kisanApp.showToast('🚚 Transport booked! Driver ${t.driverName} has confirmed pickup.')" class="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-xl text-sm text-center shadow btn-farmer-primary ripple-effect flex items-center justify-center gap-1.5">
                  <span class="text-lg">🚚</span> ${this.t('bookTruckNow')}
                </button>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  // Orders Tab
  renderOrdersTab() {
    return `
      <div class="space-y-4">
        <div class="bg-gradient-to-r from-emerald-800 to-teal-900 text-white rounded-2xl p-4 shadow-md">
          <span class="text-[10px] uppercase font-bold text-emerald-200">100% Escrow Secured Commerce</span>
          <h2 class="text-lg font-black mt-0.5">${this.t('myOrders')}</h2>
          <p class="text-xs text-emerald-100 mt-1">Payment is held securely in escrow until buyer receives and verifies produce quality.</p>
        </div>

        <div class="space-y-3.5">
          ${this.orders.map(o => `
            <div class="bg-white rounded-2xl border-2 border-emerald-500/80 p-4 shadow-md space-y-3">
              <div class="flex items-center justify-between border-b pb-2">
                <div>
                  <span class="text-xs font-black text-slate-800">${o.id}</span>
                  <span class="text-[10px] text-slate-500 block">${o.crop} (${o.variety})</span>
                </div>
                <div class="text-right">
                  <span class="text-sm font-black text-emerald-700">₹${o.totalAmount.toLocaleString('en-IN')}</span>
                  <span class="text-[10px] font-bold text-emerald-600 block">🔒 ${o.escrowStatus}</span>
                </div>
              </div>

              <div class="space-y-2">
                <span class="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Milestone Progress (Step ${o.step}/5)</span>
                <div class="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div class="bg-emerald-500 h-full rounded-full transition-all duration-500" style="width: ${(o.step / 5) * 100}%"></div>
                </div>

                <div class="space-y-1.5 pt-1">
                  ${o.timeline.map((step, idx) => `
                    <div class="flex items-center gap-2 text-xs">
                      <span class="w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-bold ${
                        step.done ? 'bg-emerald-500 text-white' : 'bg-slate-200 text-slate-600'
                      }">
                        ${step.done ? '✓' : idx + 1}
                      </span>
                      <span class="${step.done ? 'text-slate-900 font-semibold' : 'text-slate-400'}">${step.title}</span>
                      <span class="text-[10px] text-slate-400 ml-auto">${step.time}</span>
                    </div>
                  `).join('')}
                </div>
              </div>

              ${o.step < 5 ? `
                <button onclick="kisanApp.advanceOrderMilestone('${o.id}')" class="w-full bg-slate-900 hover:bg-black text-white font-bold py-2.5 rounded-xl text-xs shadow transition">
                  ⚡ Advance Order Status (${o.step === 3 ? 'Dispatch' : 'Deliver & Release Funds'})
                </button>
              ` : `
                <div class="bg-emerald-100 text-emerald-900 font-bold p-2.5 rounded-xl text-center text-xs">
                  🎉 Deal Successfully Completed & Payout Released!
                </div>
              `}
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  // Earnings Tab
  renderEarningsTab() {
    const demandRadar = this.marketEngine.getDemandForecastRadar();

    return `
      <div class="space-y-4">
        <div class="bg-gradient-to-tr from-emerald-800 to-lime-700 text-white rounded-3xl p-5 shadow-xl space-y-4">
          <div class="flex items-center justify-between">
            <div>
              <span class="text-[10px] uppercase font-bold text-emerald-200">Kisan Financial Ledger</span>
              <h2 class="text-xl font-black mt-0.5">₹1,84,500</h2>
              <span class="text-xs text-emerald-100">Total Net Realization This Season</span>
            </div>
            <div class="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center text-2xl">
              💰
            </div>
          </div>

          <div class="grid grid-cols-2 gap-2 pt-2 border-t border-white/20 text-xs">
            <div>
              <span class="text-emerald-200 block text-[10px]">Secured in Escrow:</span>
              <strong class="text-sm font-bold text-amber-300">₹1,02,000</strong>
            </div>
            <div>
              <span class="text-emerald-200 block text-[10px]">Average Premium:</span>
              <strong class="text-sm font-bold text-lime-200">+12.4% vs APMC</strong>
            </div>
          </div>
        </div>

        <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-3">
          <h3 class="text-sm font-black text-slate-800">High-Yield Sowing & Harvest Insights</h3>
          <div class="space-y-2.5">
            ${demandRadar.map(r => `
              <div class="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1 text-xs">
                <div class="flex items-center justify-between">
                  <strong class="text-slate-900 font-bold">${r.crop}</strong>
                  <span class="text-[10px] font-black text-rose-700 bg-rose-100 px-2 py-0.5 rounded-full">${r.demandLevel} Demand</span>
                </div>
                <p class="text-[11px] text-slate-600">📊 ${r.reason} (Expected: <strong>${r.priceChangeExpected}</strong>)</p>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  }

  // --- Live Mandi Ticker Methods ---
  initTickerData() {
    const mandis = window.SEED_DATA.mandis;
    this.tickerData = [];
    mandis.forEach(mandi => {
      mandi.commodities.forEach(c => {
        const key = `${c.crop}-${mandi.name}`;
        this.tickerData.push({
          key: key,
          crop: c.crop,
          variety: c.variety,
          mandi: mandi.name,
          state: mandi.state,
          currentPrice: c.modalPrice,
          basePrice: c.modalPrice,
          changePct: 0,
          trend: 'stable',
          flashClass: ''
        });
        this.tickerHistory[key] = [c.modalPrice];
      });
    });
  }

  startTicker() {
    if (this.tickerInterval) return;
    this.tickerInterval = setInterval(() => {
      this.tickerData.forEach(item => {
        const shift = (Math.random() - 0.48) * 0.04; // slight upward bias
        const newPrice = Math.round(item.currentPrice * (1 + shift));
        const changePct = ((newPrice - item.basePrice) / item.basePrice * 100).toFixed(1);
        
        item.flashClass = newPrice > item.currentPrice ? 'flash-green' : (newPrice < item.currentPrice ? 'flash-red' : '');
        item.trend = newPrice > item.currentPrice ? 'up' : (newPrice < item.currentPrice ? 'down' : 'stable');
        item.currentPrice = newPrice;
        item.changePct = parseFloat(changePct);

        const history = this.tickerHistory[item.key];
        history.push(newPrice);
        if (history.length > 8) history.shift();
      });

      // Only re-render the ticker rows, not the full app
      const tbody = document.getElementById('ticker-table-body');
      if (tbody) {
        tbody.innerHTML = this.renderTickerRows();
      }
    }, 3000);
  }

  stopTicker() {
    if (this.tickerInterval) {
      clearInterval(this.tickerInterval);
      this.tickerInterval = null;
    }
  }

  setActiveTab(tab) {
    if (this.activeTab === 'ticker_live' && tab !== 'ticker_live') {
      this.stopTicker();
    }
    this.activeTab = tab;
    this.render();
    if (tab === 'ticker_live') {
      this.startTicker();
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  renderTickerRows() {
    let data = [...this.tickerData];
    if (this.tickerSortMode === 'gainers') {
      data = data.filter(d => d.changePct > 0).sort((a, b) => b.changePct - a.changePct);
    } else if (this.tickerSortMode === 'losers') {
      data = data.filter(d => d.changePct < 0).sort((a, b) => a.changePct - b.changePct);
    }

    if (data.length === 0) {
      return `<tr><td colspan="5" class="p-6 text-center text-slate-400 text-xs">${this.t('noListingsFound')}</td></tr>`;
    }

    return data.map(item => {
      const history = this.tickerHistory[item.key] || [];
      const maxH = Math.max(...history);
      const minH = Math.min(...history);
      const range = maxH - minH || 1;

      const sparkBars = history.map(h => {
        const pct = Math.max(15, ((h - minH) / range) * 100);
        const color = h >= item.basePrice ? 'bg-emerald-500' : 'bg-rose-500';
        return `<div class="${color} rounded-sm" style="width:6px;height:${pct}%"></div>`;
      }).join('');

      const trendIcon = item.changePct > 0 ? '▲' : (item.changePct < 0 ? '▼' : '●');
      const trendColor = item.changePct > 0 ? 'ticker-price-up' : (item.changePct < 0 ? 'ticker-price-down' : 'text-slate-500');
      const sign = item.changePct > 0 ? '+' : '';

      return `
        <tr class="${item.flashClass} transition-colors duration-300">
          <td class="px-3 py-2.5">
            <div class="font-bold text-xs text-slate-900">${item.crop}</div>
            <div class="text-[10px] text-slate-500">${item.variety}</div>
          </td>
          <td class="px-2 py-2.5 text-right">
            <span class="font-black text-sm text-slate-900">₹${item.currentPrice.toLocaleString('en-IN')}</span>
          </td>
          <td class="px-2 py-2.5 text-right">
            <span class="font-bold text-xs ${trendColor}">
              ${trendIcon} ${sign}${item.changePct}%
            </span>
          </td>
          <td class="px-2 py-2.5">
            <div class="text-[10px] text-slate-600 truncate max-w-[80px]">${item.mandi}</div>
          </td>
          <td class="px-2 py-2.5">
            <div class="flex items-end gap-px h-6">${sparkBars}</div>
          </td>
        </tr>
      `;
    }).join('');
  }

  renderLiveTickerTab() {
    return `
      <div class="space-y-4 animate-fadeIn">
        <!-- Ticker Banner -->
        <div class="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white rounded-3xl p-5 shadow-xl space-y-2">
          <div class="flex items-center justify-between">
            <span class="bg-lime-400 text-slate-950 text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider animate-pulse">
              ● ${this.t('marketOpen')}
            </span>
            <span class="text-[10px] text-slate-400 font-mono">${this.t('simulatedData')}</span>
          </div>
          <h2 class="text-xl font-black">${this.t('tickerTitle')}</h2>
          <p class="text-xs text-emerald-100">${this.t('tickerDesc')}</p>
        </div>

        <!-- Sort Filters -->
        <div class="flex items-center gap-2">
          <button onclick="kisanApp.tickerSortMode='all'; kisanApp.render(); kisanApp.startTicker();" class="text-xs px-4 py-2 rounded-full font-bold transition ${this.tickerSortMode === 'all' ? 'bg-emerald-700 text-white shadow' : 'bg-white text-slate-600 border border-slate-200'}">
            ${this.t('allCommodities')}
          </button>
          <button onclick="kisanApp.tickerSortMode='gainers'; kisanApp.render(); kisanApp.startTicker();" class="text-xs px-4 py-2 rounded-full font-bold transition ${this.tickerSortMode === 'gainers' ? 'bg-emerald-700 text-white shadow' : 'bg-white text-slate-600 border border-slate-200'}">
            📈 ${this.t('topGainers')}
          </button>
          <button onclick="kisanApp.tickerSortMode='losers'; kisanApp.render(); kisanApp.startTicker();" class="text-xs px-4 py-2 rounded-full font-bold transition ${this.tickerSortMode === 'losers' ? 'bg-emerald-700 text-white shadow' : 'bg-white text-slate-600 border border-slate-200'}">
            📉 ${this.t('topLosers')}
          </button>
        </div>

        <!-- Ticker Table -->
        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <table class="w-full text-left">
            <thead>
              <tr class="bg-slate-900 text-white text-[10px] uppercase tracking-wider">
                <th class="px-3 py-2.5 font-bold">${this.t('commodity')}</th>
                <th class="px-2 py-2.5 font-bold text-right">${this.t('currentPrice')}</th>
                <th class="px-2 py-2.5 font-bold text-right">${this.t('change')}</th>
                <th class="px-2 py-2.5 font-bold">${this.t('mandi')}</th>
                <th class="px-2 py-2.5 font-bold">${this.t('last8Ticks')}</th>
              </tr>
            </thead>
            <tbody id="ticker-table-body" class="divide-y divide-slate-100">
              ${this.renderTickerRows()}
            </tbody>
          </table>
        </div>
      </div>
    `;
  }
}

// Instantiate on DOM load
window.addEventListener('DOMContentLoaded', () => {
  window.kisanApp = new KisanApp();
});
