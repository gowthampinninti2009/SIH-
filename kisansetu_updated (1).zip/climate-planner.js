// KisanSetu (AgriLink) - Climate Resilience Planner & Alternative Crop Suggestion Engine

class ClimateResiliencePlanner {
  constructor() {
    this.climateProfiles = window.SEED_DATA ? window.SEED_DATA.climateRegionProfiles : [];
    this.alternativeCrops = window.SEED_DATA ? window.SEED_DATA.climateResilientCrops : [];
    this.subsidies = window.SEED_DATA ? window.SEED_DATA.climateSubsidies : [];
    
    this.selectedRegion = localStorage.getItem('kisan_climate_region') || 'Deccan Plateau (Semi-Arid)';
    this.selectedCurrentCrop = localStorage.getItem('kisan_climate_current_crop') || 'Paddy (Rice)';
  }

  savePreferences(region, currentCrop) {
    this.selectedRegion = region;
    this.selectedCurrentCrop = currentCrop;
    localStorage.setItem('kisan_climate_region', region);
    localStorage.setItem('kisan_climate_current_crop', currentCrop);
  }

  // Analyze Climate Risk for the farmer's current setup
  analyzeClimateRisk(regionName, currentCropName) {
    const region = this.climateProfiles.find(r => r.name === regionName) || this.climateProfiles[0];
    
    // Risk heuristics based on crop water & temperature sensitivity
    const cropSensitivity = {
      "Paddy (Rice)": { waterIntensity: "Very High (1,200 - 1,800 mm)", heatTolerance: "Low", droughtVulnerability: 88, soilDegradationRisk: "High (Methane & Waterlogging)" },
      "Sugarcane": { waterIntensity: "Extremely High (2,000 mm)", heatTolerance: "Moderate", droughtVulnerability: 92, soilDegradationRisk: "High (Soil nutrient exhaustion)" },
      "Cotton": { waterIntensity: "Moderate-High (700 - 1,100 mm)", heatTolerance: "Moderate", droughtVulnerability: 74, soilDegradationRisk: "Moderate (Pesticide residue)" },
      "Tomato": { waterIntensity: "Moderate (400 - 600 mm)", heatTolerance: "Low", droughtVulnerability: 68, soilDegradationRisk: "Moderate" },
      "Wheat": { waterIntensity: "Moderate (450 - 650 mm)", heatTolerance: "Very Low (Terminal heat shock)", droughtVulnerability: 65, soilDegradationRisk: "Low" }
    };

    const sensitivity = cropSensitivity[currentCropName] || { waterIntensity: "Moderate", heatTolerance: "Moderate", droughtVulnerability: 60, soilDegradationRisk: "Moderate" };

    // Calculate Overall Climate Vulnerability Score (1 - 100)
    const climateRiskScore = Math.min(96, Math.round((sensitivity.droughtVulnerability * 0.5) + (region.waterDeficitIndex * 0.3) + (region.heatwaveIndex * 0.2)));

    let riskLevel = "Severe Risk 🔴";
    if (climateRiskScore < 50) riskLevel = "Low Risk 🟢";
    else if (climateRiskScore < 75) riskLevel = "Moderate-High Risk 🟠";

    return {
      region: region.name,
      currentCrop: currentCropName,
      riskScore: climateRiskScore,
      riskLevel: riskLevel,
      projectedRainfallShift: region.rainfallShift,
      projectedTempRise: region.tempRise,
      groundwaterStatus: region.groundwaterTable,
      sensitivity: sensitivity,
      aiAlert: `⚠️ In ${region.name}, ${currentCropName} faces ${riskLevel} due to ${region.rainfallShift} and ${region.groundwaterTable}. Continuing conventional cultivation risks 35-50% yield reduction by next season.`
    };
  }

  // Suggest Alternative Climate-Resilient Crops
  getAlternativeCropRecommendations(regionName, currentCropName) {
    const riskAnalysis = this.analyzeClimateRisk(regionName, currentCropName);

    return this.alternativeCrops.map(alt => {
      // Calculate savings & profit advantage vs conventional crop
      const waterSavedPct = alt.waterReductionPct;
      const inputCostSavedPct = alt.costReductionPct;
      const netProfitPerAcre = alt.estimatedNetProfitPerAcre;
      const mspSupport = alt.hasGovtMSP;
      const suitabilityScore = Math.min(99, Math.max(82, 95 - Math.abs(riskAnalysis.riskScore - alt.resilienceScore)));

      return {
        ...alt,
        suitabilityScore,
        waterSavedPct,
        inputCostSavedPct,
        netProfitPerAcre,
        mspSupport,
        isTopPick: suitabilityScore >= 92
      };
    }).sort((a, b) => b.suitabilityScore - a.suitabilityScore);
  }

  // Get Transition Roadmap & Subsidies for a selected alternative crop
  getTransitionRoadmap(altCropId) {
    const crop = this.alternativeCrops.find(c => c.id === altCropId) || this.alternativeCrops[0];
    const applicableSubsidies = this.subsidies.filter(s => s.applicableCrops.includes(crop.name) || s.applicableCrops.includes("All Climate-Smart"));

    return {
      crop,
      applicableSubsidies,
      sowingWindow: crop.idealSowingWindow,
      seedRequirementPerAcre: crop.seedRatePerAcre,
      expectedHarvestDays: crop.maturityDays,
      buyersReady: crop.buyerDemandNetwork
    };
  }
}

if (typeof window !== 'undefined') {
  window.ClimateResiliencePlanner = ClimateResiliencePlanner;
}
