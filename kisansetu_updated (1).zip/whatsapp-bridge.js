// KisanSetu (AgriLink) - WhatsApp Bridge & Push Alerts Engine

class WhatsAppBridgeEngine {
  constructor() {
    this.subscribedNumber = localStorage.getItem('kisan_wa_phone') || '+91 98765 43210';
    this.alertsEnabled = localStorage.getItem('kisan_wa_enabled') !== 'false';
    this.alertFrequency = localStorage.getItem('kisan_wa_freq') || 'daily_morning'; // 'daily_morning' | 'instant_offers'
    this.preferredCrops = JSON.parse(localStorage.getItem('kisan_wa_crops') || '["Tomato", "Onion", "Paddy (Rice)"]');
  }

  savePreferences(phone, enabled, freq, crops) {
    this.subscribedNumber = phone;
    this.alertsEnabled = enabled;
    this.alertFrequency = freq;
    this.preferredCrops = crops;

    localStorage.setItem('kisan_wa_phone', phone);
    localStorage.setItem('kisan_wa_enabled', enabled.toString());
    localStorage.setItem('kisan_wa_freq', freq);
    localStorage.setItem('kisan_wa_crops', JSON.stringify(crops));
  }

  // Generate direct wa.me link for sending market update or trade offer
  generateWhatsAppShareUrl(text, phone = "") {
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    const encodedText = encodeURIComponent(text);
    if (cleanPhone) {
      return `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodedText}`;
    }
    return `https://api.whatsapp.com/send?text=${encodedText}`;
  }

  // Generate formatted WhatsApp text for Daily Mandi Rates
  getDailyMandiBroadcastText(mandiName = "Azadpur Mandi") {
    const date = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
    return `🌾 *KisanSetu Daily Mandi Alert* [${date}]\n` +
      `📍 *Market:* ${mandiName}\n\n` +
      `📈 *Today's Top Rates:*\n` +
      `• 🍅 *Tomato (Hybrid):* ₹2,100 - ₹2,600/qtl (🔺 +5.8%)\n` +
      `• 🧅 *Onion (Nashik Red):* ₹2,750 - ₹3,200/qtl (🔺 +3.2%)\n` +
      `• 🌾 *Paddy (Sona Masoori):* ₹2,580 - ₹2,950/qtl (🔺 +2.5%)\n` +
      `• 🥔 *Potato (Jyoti):* ₹1,450 - ₹1,800/qtl (⚖️ Stable)\n\n` +
      `💡 *AI Advisory:* Tomato prices expected to peak this weekend due to festival demand.\n\n` +
      `📲 *To sell directly with zero middleman fees:* https://kisansetu.app/sell`;
  }

  // Generate formatted WhatsApp text for Buyer Offer
  getBuyerOfferAlertText(buyerName, crop, qty, price, location) {
    const total = (qty * price).toLocaleString('en-IN');
    return `🔔 *KisanSetu Instant Buyer Offer Alert!*\n\n` +
      `🏢 *Buyer:* ${buyerName} (Verified 5.0★)\n` +
      `🌾 *Crop:* ${crop}\n` +
      `⚖️ *Quantity Needed:* ${qty} quintals\n` +
      `💰 *Offered Rate:* ₹${price}/quintal\n` +
      `💵 *Total Escrow Value:* ₹${total}\n` +
      `📍 *Delivery Hub:* ${location}\n\n` +
      `👉 *Reply to this message with:*\n` +
      `• Type *1* to ACCEPT & lock Escrow\n` +
      `• Type *2* to COUNTER offer with your rate\n` +
      `• Type *3* to talk to the buyer directly`;
  }

  // Generate shareable produce listing text for WhatsApp groups
  getShareableListingText(listing) {
    return `🌾 *FRESH PRODUCE AVAILABLE DIRECT FROM FARM*\n\n` +
      `🌾 *Crop:* ${listing.crop} (${listing.variety})\n` +
      `⚖️ *Quantity:* ${listing.quantity} ${listing.unit}\n` +
      `💰 *Direct Farm Price:* ₹${listing.pricePerUnit} / ${listing.unit}\n` +
      `✅ *AI Quality Grade:* ${listing.qualityGrade} (${listing.qualityScore}/100 Freshness)\n` +
      `📍 *Location:* ${listing.location}\n` +
      `👨‍🌾 *Farmer:* ${listing.farmerName} (${listing.phone})\n` +
      `🔒 *100% Escrow Secured Payment*\n\n` +
      `📲 View full verified certificate & place order: https://kisansetu.app/list/${listing.id}`;
  }
}

if (typeof window !== 'undefined') {
  window.WhatsAppBridgeEngine = WhatsAppBridgeEngine;
}
