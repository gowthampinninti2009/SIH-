// KisanSetu (AgriLink) - Mandi Price Discovery & AI Market Intelligence Engine

class KisanMarketEngine {
  constructor() {
    this.mandis = window.SEED_DATA ? window.SEED_DATA.mandis : [];
  }

  // Get all unique commodities across all mandis
  getAllCommodities() {
    const crops = new Set();
    this.mandis.forEach(m => {
      m.commodities.forEach(c => crops.add(c.crop));
    });
    return Array.from(crops);
  }

  // Get price data for a specific crop across all mandis
  getCropPriceAcrossMandis(cropName) {
    const results = [];
    this.mandis.forEach(m => {
      const match = m.commodities.find(c => c.crop.toLowerCase() === cropName.toLowerCase());
      if (match) {
        results.push({
          mandiId: m.id,
          mandiName: m.name,
          state: m.state,
          district: m.district,
          distanceKm: m.distanceKm,
          ...match
        });
      }
    });
    return results.sort((a, b) => b.modalPrice - a.modalPrice);
  }

  // Generate 7-day AI Price Forecast and Market Sentiment
  generate7DayForecast(cropName) {
    const historicalDays = ["Day -6", "Day -5", "Day -4", "Day -3", "Day -2", "Yesterday", "Today"];
    const futureDays = ["Tomorrow", "Day +2", "Day +3", "Day +4", "Day +5", "Day +6", "Day +7"];
    
    // Base prices by crop
    const baseRates = {
      "Tomato": { base: 2100, trend: "up", change: "+14.2%", advice: "📈 Strong upward momentum due to heavy rainfall in southern belts. Hold or sell in staggered batches for maximum realization." },
      "Onion": { base: 2850, trend: "up", change: "+8.5%", advice: "📈 Storage stocks declining in northern hubs. Prices expected to rise ₹150-₹200/qtl in coming week." },
      "Wheat": { base: 2600, trend: "stable", change: "+1.8%", advice: "⚖️ Steady procurement by flour mills and FCI. Stable market corridor." },
      "Paddy (Rice)": { base: 2750, trend: "up", change: "+5.4%", advice: "📈 Export demand for medium and long grain paddy is robust." },
      "Red Chilli": { base: 22000, trend: "up", change: "+9.0%", advice: "🔥 High export inquiries from Southeast Asia and Gulf. Premium grades commanding top dollar." },
      "Potato": { base: 1450, trend: "stable", change: "+0.5%", advice: "⚖️ Cold storage releases are well matched with daily consumption." },
      "Soybean": { base: 4600, trend: "up", change: "+4.1%", advice: "📈 Global edible oil futures surging. Crushers actively buying." },
      "Cotton": { base: 7400, trend: "up", change: "+3.6%", advice: "📈 Textile spinning mills ramping up yarn orders." }
    };

    const info = baseRates[cropName] || { base: 2000, trend: "stable", change: "+2.0%", advice: "Balanced supply and demand conditions." };
    
    const historical = [];
    let current = info.base * 0.94;
    for (let i = 0; i < 7; i++) {
      current += (Math.random() * 40 - 15);
      historical.push({ day: historicalDays[i], price: Math.round(current) });
    }

    const forecast = [];
    let fPrice = info.base;
    for (let i = 0; i < 7; i++) {
      const delta = info.trend === "up" ? (Math.random() * 45 + 15) : (Math.random() * 30 - 15);
      fPrice += delta;
      forecast.push({ day: futureDays[i], price: Math.round(fPrice) });
    }

    return {
      crop: cropName,
      basePrice: info.base,
      trend: info.trend,
      changePct: info.change,
      aiAdvice: info.advice,
      historical,
      forecast
    };
  }

  // Calculate Best Mandi Arbitrage (Net Profit after Transport Costs)
  calculateBestMandiArbitrage(cropName, quantityQuintals = 50, transportRatePerKm = 25) {
    const cropMandis = this.getCropPriceAcrossMandis(cropName);
    if (cropMandis.length === 0) return [];

    // Assume closest mandi is the baseline local mandi
    const localMandi = [...cropMandis].sort((a, b) => a.distanceKm - b.distanceKm)[0];
    const localTransportCost = localMandi.distanceKm * transportRatePerKm;
    const localGrossRevenue = localMandi.modalPrice * quantityQuintals;
    const localApmcHandling = localGrossRevenue * 0.015; // 1.5% handling fee
    const localNetProfit = localGrossRevenue - localTransportCost - localApmcHandling;

    return cropMandis.map(m => {
      const grossRevenue = m.modalPrice * quantityQuintals;
      const transportCost = m.distanceKm * transportRatePerKm;
      const apmcHandling = grossRevenue * 0.015;
      const netProfit = grossRevenue - transportCost - apmcHandling;
      const netProfitPerQuintal = Math.round(netProfit / quantityQuintals);
      const profitDiffTotal = netProfit - localNetProfit;
      const isRecommended = profitDiffTotal > 0;

      return {
        mandiId: m.mandiId,
        mandiName: m.mandiName || m.name || "APMC Mandi",
        state: m.state,
        distanceKm: m.distanceKm,
        modalPrice: m.modalPrice,
        grossRevenue: Math.round(grossRevenue),
        transportCost: Math.round(transportCost),
        apmcHandling: Math.round(apmcHandling),
        netProfit: Math.round(netProfit),
        netProfitPerQuintal,
        profitDiffTotal: Math.round(profitDiffTotal),
        isRecommended,
        isLocalBase: m.mandiId === localMandi.mandiId
      };
    }).sort((a, b) => b.netProfit - a.netProfit);
  }

  // AI Demand Intelligence highlights
  getDemandForecastRadar() {
    return [
      { crop: "Tomato", demandLevel: "Very High", reason: "Festival season surge & southern supply deficit", priceChangeExpected: "+12% to +18%", recommendedAction: "Harvest firm breaker stage for long-haul buyers" },
      { crop: "Red Chilli", demandLevel: "High", reason: "Spice exporters actively securing export grade Teja", priceChangeExpected: "+8% to +14%", recommendedAction: "Sun dry to <11% moisture for top grade realization" },
      { crop: "Onion", demandLevel: "High", reason: "Wholesale terminal markets reporting 25% lower daily arrivals", priceChangeExpected: "+6% to +10%", recommendedAction: "Grade into 50mm+ lots for restaurant chains" },
      { crop: "Basmati Paddy", demandLevel: "Very High", reason: "Middle-East export contracts opening up", priceChangeExpected: "+5% to +8%", recommendedAction: "List under Harvest Pre-Booking for locked advance" }
    ];
  }
}

if (typeof window !== 'undefined') {
  window.KisanMarketEngine = KisanMarketEngine;
}
