// KisanSetu (AgriLink) - Farmer Peer Pairing & Farm Duels Leaderboard Engine

class FarmerDuelsEngine {
  constructor() {
    this.peers = window.SEED_DATA ? window.SEED_DATA.peerFarmers : [];
    this.userFarmerProfile = this.loadUserProfile();
    this.leaderboard = window.SEED_DATA ? window.SEED_DATA.farmerLeaderboard : [];
    this.activeDuelOpponentId = this.peers.length > 0 ? this.peers[0].id : null;
  }

  loadUserProfile() {
    try {
      const stored = localStorage.getItem('kisan_my_profile');
      return stored ? JSON.parse(stored) : {
        id: "me",
        name: "Gowtham Kisan (You)",
        location: "Guntur District, AP",
        landAcres: 4.5,
        soilType: "Black Alluvial",
        crop: "Paddy (Rice)",
        variety: "Sona Masoori",
        equipment: ["Drip Kit", "Power Tiller", "Moisture Meter"],
        yieldPerAcre: 28.5, // Quintals per acre
        qualityScorePct: 94,
        avgPriceRealized: 2580,
        mandiBenchmark: 2450,
        waterEfficiencyScore: 92,
        kisanPowerScore: 890,
        rank: 4
      };
    } catch (e) {
      return {
        id: "me",
        name: "Gowtham Kisan (You)",
        location: "Guntur District, AP",
        landAcres: 4.5,
        soilType: "Black Alluvial",
        crop: "Paddy (Rice)",
        variety: "Sona Masoori",
        equipment: ["Drip Kit", "Power Tiller", "Moisture Meter"],
        yieldPerAcre: 28.5,
        qualityScorePct: 94,
        avgPriceRealized: 2580,
        mandiBenchmark: 2450,
        waterEfficiencyScore: 92,
        kisanPowerScore: 890,
        rank: 4
      };
    }
  }

  // Find most compatible peer farmers with similar land & equipment
  findSimilarPeers() {
    return this.peers.map(peer => {
      // Calculate land size similarity
      const landDiff = Math.abs(peer.landAcres - this.userFarmerProfile.landAcres);
      const landMatchScore = Math.max(0, 100 - (landDiff * 15));

      // Crop similarity
      const cropMatchScore = peer.crop.toLowerCase() === this.userFarmerProfile.crop.toLowerCase() ? 100 : 60;

      // Equipment match
      const equipOverlap = peer.equipment.filter(e => this.userFarmerProfile.equipment.includes(e)).length;
      const equipScore = Math.min(100, equipOverlap * 35);

      const overallCompatibility = Math.round((landMatchScore * 0.4) + (cropMatchScore * 0.4) + (equipScore * 0.2));

      return {
        ...peer,
        compatibilityScore: overallCompatibility
      };
    }).sort((a, b) => b.compatibilityScore - a.compatibilityScore);
  }

  // Compare user with a peer farmer
  getDuelComparison(peerId) {
    const peer = this.peers.find(p => p.id === peerId) || this.peers[0];
    const user = this.userFarmerProfile;

    const metrics = [
      {
        title: "Yield Per Acre (Quintals)",
        myVal: user.yieldPerAcre,
        peerVal: peer.yieldPerAcre,
        winner: user.yieldPerAcre >= peer.yieldPerAcre ? 'me' : 'peer',
        diff: (user.yieldPerAcre - peer.yieldPerAcre).toFixed(1) + " qtl/acre"
      },
      {
        title: "Produce AI Quality Score",
        myVal: user.qualityScorePct + "%",
        peerVal: peer.qualityScorePct + "%",
        winner: user.qualityScorePct >= peer.qualityScorePct ? 'me' : 'peer',
        diff: (user.qualityScorePct - peer.qualityScorePct) + "%"
      },
      {
        title: "Price Realization Over APMC",
        myVal: "₹" + (user.avgPriceRealized - user.mandiBenchmark) + "/qtl",
        peerVal: "₹" + (peer.avgPriceRealized - peer.mandiBenchmark) + "/qtl",
        winner: (user.avgPriceRealized - user.mandiBenchmark) >= (peer.avgPriceRealized - peer.mandiBenchmark) ? 'me' : 'peer',
        diff: "₹" + ((user.avgPriceRealized - user.mandiBenchmark) - (peer.avgPriceRealized - peer.mandiBenchmark)) + "/qtl"
      },
      {
        title: "Water & Input Efficiency",
        myVal: user.waterEfficiencyScore + "/100",
        peerVal: peer.waterEfficiencyScore + "/100",
        winner: user.waterEfficiencyScore >= peer.waterEfficiencyScore ? 'me' : 'peer',
        diff: (user.waterEfficiencyScore - peer.waterEfficiencyScore) + " pts"
      }
    ];

    let userWins = metrics.filter(m => m.winner === 'me').length;
    let peerWins = metrics.filter(m => m.winner === 'peer').length;

    let duelVerdict = userWins > peerWins ? "🎉 You are Leading this Season Duel!" : "⚔️ Close Match! Adopt Soil & Drip Advice to Overtake!";

    return {
      user,
      peer,
      metrics,
      userWins,
      peerWins,
      verdict: duelVerdict
    };
  }
}

if (typeof window !== 'undefined') {
  window.FarmerDuelsEngine = FarmerDuelsEngine;
}
