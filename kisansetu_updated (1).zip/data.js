// KisanSetu (AgriLink) - Core Data Store

const SEED_DATA = {
  // 1. APMC Mandi Reference Rates across key states & districts
  mandis: [
    {
      id: "mandi-1",
      name: "Azadpur Mandi",
      state: "Delhi",
      district: "North Delhi",
      distanceKm: 28,
      commodities: [
        { crop: "Tomato", variety: "Hybrid Red", minPrice: 1600, modalPrice: 2100, maxPrice: 2600, unit: "quintal", trend: "up", changePct: +5.8, arrivals: 420 },
        { crop: "Onion", variety: "Nashik Red", minPrice: 2200, modalPrice: 2750, maxPrice: 3200, unit: "quintal", trend: "up", changePct: +3.2, arrivals: 850 },
        { crop: "Potato", variety: "Jyoti", minPrice: 1100, modalPrice: 1450, maxPrice: 1800, unit: "quintal", trend: "stable", changePct: 0.0, arrivals: 920 },
        { crop: "Wheat", variety: "Sharbati", minPrice: 2400, modalPrice: 2850, maxPrice: 3300, unit: "quintal", trend: "up", changePct: +2.1, arrivals: 600 },
        { crop: "Green Chilli", variety: "G4", minPrice: 3500, modalPrice: 4200, maxPrice: 5000, unit: "quintal", trend: "down", changePct: -4.5, arrivals: 180 }
      ]
    },
    {
      id: "mandi-2",
      name: "Lasalgaon APMC",
      state: "Maharashtra",
      district: "Nashik",
      distanceKm: 180,
      commodities: [
        { crop: "Onion", variety: "Garwa / Red", minPrice: 2400, modalPrice: 2950, maxPrice: 3500, unit: "quintal", trend: "up", changePct: +8.1, arrivals: 2200 },
        { crop: "Pomegranate", variety: "Bhagwa", minPrice: 8000, modalPrice: 11500, maxPrice: 16000, unit: "quintal", trend: "up", changePct: +4.6, arrivals: 310 },
        { crop: "Soybean", variety: "Yellow", minPrice: 4100, modalPrice: 4550, maxPrice: 4900, unit: "quintal", trend: "stable", changePct: +0.5, arrivals: 740 },
        { crop: "Tomato", variety: "Local", minPrice: 1400, modalPrice: 1850, maxPrice: 2300, unit: "quintal", trend: "down", changePct: -3.1, arrivals: 650 }
      ]
    },
    {
      id: "mandi-3",
      name: "Khanna Grain Market",
      state: "Punjab",
      district: "Ludhiana",
      distanceKm: 290,
      commodities: [
        { crop: "Wheat", variety: "PBW 550 / HD 3086", minPrice: 2275, modalPrice: 2450, maxPrice: 2650, unit: "quintal", trend: "stable", changePct: +1.0, arrivals: 3400 },
        { crop: "Paddy (Rice)", variety: "Basmati 1121", minPrice: 3800, modalPrice: 4350, maxPrice: 4900, unit: "quintal", trend: "up", changePct: +6.2, arrivals: 1950 },
        { crop: "Mustard", variety: "Black", minPrice: 5100, modalPrice: 5650, maxPrice: 6200, unit: "quintal", trend: "up", changePct: +2.8, arrivals: 430 }
      ]
    },
    {
      id: "mandi-4",
      name: "Kurnool Agricultural Market",
      state: "Andhra Pradesh",
      district: "Kurnool",
      distanceKm: 140,
      commodities: [
        { crop: "Cotton", variety: "Medium Staple", minPrice: 6800, modalPrice: 7450, maxPrice: 8100, unit: "quintal", trend: "up", changePct: +3.9, arrivals: 890 },
        { crop: "Red Chilli", variety: "Teja / Guntur", minPrice: 17000, modalPrice: 21500, maxPrice: 26000, unit: "quintal", trend: "up", changePct: +7.4, arrivals: 410 },
        { crop: "Groundnut", variety: "Bold", minPrice: 5900, modalPrice: 6600, maxPrice: 7300, unit: "quintal", trend: "stable", changePct: +0.4, arrivals: 520 },
        { crop: "Paddy (Rice)", variety: "Sona Masoori", minPrice: 2200, modalPrice: 2600, maxPrice: 2950, unit: "quintal", trend: "up", changePct: +2.5, arrivals: 1100 }
      ]
    },
    {
      id: "mandi-5",
      name: "Bowenpally Market",
      state: "Telangana",
      district: "Hyderabad",
      distanceKm: 65,
      commodities: [
        { crop: "Tomato", variety: "Hybrid Red", minPrice: 1750, modalPrice: 2250, maxPrice: 2700, unit: "quintal", trend: "up", changePct: +4.2, arrivals: 560 },
        { crop: "Paddy (Rice)", variety: "BPT 5204", minPrice: 2350, modalPrice: 2750, maxPrice: 3100, unit: "quintal", trend: "stable", changePct: +1.1, arrivals: 890 },
        { crop: "Turmeric", variety: "Nizamabad Salem", minPrice: 12500, modalPrice: 15400, maxPrice: 18200, unit: "quintal", trend: "up", changePct: +9.3, arrivals: 320 },
        { crop: "Maize (Corn)", variety: "Hybrid", minPrice: 2000, modalPrice: 2250, maxPrice: 2480, unit: "quintal", trend: "stable", changePct: -0.8, arrivals: 640 }
      ]
    },
    {
      id: "mandi-6",
      name: "Indore Mandi",
      state: "Madhya Pradesh",
      district: "Indore",
      distanceKm: 210,
      commodities: [
        { crop: "Soybean", variety: "JS 9560", minPrice: 4300, modalPrice: 4720, maxPrice: 5100, unit: "quintal", trend: "up", changePct: +3.5, arrivals: 1450 },
        { crop: "Wheat", variety: "Lokwan", minPrice: 2500, modalPrice: 2900, maxPrice: 3400, unit: "quintal", trend: "up", changePct: +2.0, arrivals: 1200 },
        { crop: "Garlic", variety: "Desi", minPrice: 9000, modalPrice: 13500, maxPrice: 19000, unit: "quintal", trend: "up", changePct: +11.2, arrivals: 280 }
      ]
    }
  ],

  // 2. Active Farmer Produce Listings
  listings: [
    {
      id: "list-101",
      farmerId: "farmer-1",
      farmerName: "Rameshwar Patel",
      phone: "+91 98765 43210",
      location: "Guntur, Andhra Pradesh",
      distanceKm: 14,
      crop: "Paddy (Rice)",
      variety: "Sona Masoori (A-Grade)",
      quantity: 80,
      unit: "quintal",
      minOrderQty: 10,
      pricePerUnit: 2580,
      mandiRefPrice: 2450,
      priceAdvantage: "+₹130/qtl over APMC",
      harvestDate: "2026-08-20",
      isPreBooking: false,
      organicCertified: true,
      qualityScore: 94,
      qualityGrade: "Grade A+",
      moistureContent: "12.8%",
      shelfLifeDays: 365,
      photos: [
        "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80"
      ],
      description: "Direct sun-dried Sona Masoori paddy. Golden grain with 12.8% moisture level. Perfect for premium rice millers and exporters. Zero chemical post-harvest treatment.",
      trustScore: 4.9,
      dealsCompleted: 38,
      verifiedLandRecord: true,
      logisticsAssistance: true,
      createdAt: "2026-08-27T10:30:00Z"
    },
    {
      id: "list-102",
      farmerId: "farmer-2",
      farmerName: "Baldev Singh",
      phone: "+91 98123 78901",
      location: "Ludhiana, Punjab",
      distanceKm: 42,
      crop: "Wheat",
      variety: "Sharbati Gold",
      quantity: 150,
      unit: "quintal",
      minOrderQty: 25,
      pricePerUnit: 2920,
      mandiRefPrice: 2850,
      priceAdvantage: "+₹70/qtl over Mandi",
      harvestDate: "2026-08-18",
      isPreBooking: false,
      organicCertified: false,
      qualityScore: 91,
      qualityGrade: "Grade A",
      moistureContent: "11.5%",
      shelfLifeDays: 300,
      photos: [
        "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=600&q=80"
      ],
      description: "Lustrous Sharbati whole grain wheat. Cleaned, graded, and bagged in 50kg standard jute gunny bags. Ready for prompt dispatch.",
      trustScore: 4.8,
      dealsCompleted: 64,
      verifiedLandRecord: true,
      logisticsAssistance: true,
      createdAt: "2026-08-28T08:15:00Z"
    },
    {
      id: "list-103",
      farmerId: "farmer-3",
      farmerName: "Savitri Devi",
      phone: "+91 94567 11223",
      location: "Nashik, Maharashtra",
      distanceKm: 8,
      crop: "Onion",
      variety: "Nashik Red Garwa",
      quantity: 120,
      unit: "quintal",
      minOrderQty: 20,
      pricePerUnit: 2850,
      mandiRefPrice: 2750,
      priceAdvantage: "+₹100/qtl fair price",
      harvestDate: "2026-08-25",
      isPreBooking: false,
      organicCertified: false,
      qualityScore: 96,
      qualityGrade: "Export Grade A+",
      moistureContent: "Dry cured",
      shelfLifeDays: 90,
      photos: [
        "https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?auto=format&fit=crop&w=600&q=80"
      ],
      description: "Naturally cured medium-large uniform red onions. Tight skin, dry necks, ideal for long-distance transit and supermarket retail racks.",
      trustScore: 5.0,
      dealsCompleted: 42,
      verifiedLandRecord: true,
      logisticsAssistance: true,
      createdAt: "2026-08-28T14:40:00Z"
    },
    {
      id: "list-104",
      farmerId: "farmer-4",
      farmerName: "Venkatesh Rao",
      phone: "+91 99880 33445",
      location: "Kolar, Karnataka",
      distanceKm: 32,
      crop: "Tomato",
      variety: "Hybrid Himsona Red",
      quantity: 65,
      unit: "quintal",
      minOrderQty: 10,
      pricePerUnit: 2050,
      mandiRefPrice: 1950,
      priceAdvantage: "+₹100/qtl direct fresh",
      harvestDate: "2026-08-29",
      isPreBooking: false,
      organicCertified: true,
      qualityScore: 93,
      qualityGrade: "Grade A",
      moistureContent: "Fresh pick",
      shelfLifeDays: 14,
      photos: [
        "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=600&q=80"
      ],
      description: "Plump, firm-rind tomatoes packed in 25kg crates. Picked today morning at breaker stage for 10-14 day shelf life in retail stores and restaurants.",
      trustScore: 4.7,
      dealsCompleted: 29,
      verifiedLandRecord: true,
      logisticsAssistance: true,
      createdAt: "2026-08-29T06:00:00Z"
    },
    {
      id: "list-105",
      farmerId: "farmer-5",
      farmerName: "Gurpreet Dhillon",
      phone: "+91 97765 88990",
      location: "Karnal, Haryana",
      distanceKm: 55,
      crop: "Paddy (Rice)",
      variety: "Pusa Basmati 1121 Extra Long",
      quantity: 200,
      unit: "quintal",
      minOrderQty: 50,
      pricePerUnit: 4450,
      mandiRefPrice: 4300,
      priceAdvantage: "+₹150/qtl premium grain",
      harvestDate: "2026-09-20",
      isPreBooking: true,
      organicCertified: true,
      qualityScore: 98,
      qualityGrade: "Export Grade Premium",
      moistureContent: "Pre-harvest standing",
      shelfLifeDays: 720,
      photos: [
        "https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?auto=format&fit=crop&w=600&q=80"
      ],
      description: "🌾 [PRE-BOOKING BEFORE HARVEST] 8.4mm average grain length Basmati. Expected harvest in 22 days. Lock price now with 10% refundable advance token.",
      trustScore: 4.9,
      dealsCompleted: 75,
      verifiedLandRecord: true,
      logisticsAssistance: true,
      createdAt: "2026-08-26T12:00:00Z"
    }
  ],

  // 3. Buyer Demands & Direct Requirements Board
  demands: [
    {
      id: "dem-201",
      buyerId: "buyer-1",
      buyerName: "FreshBazaar Retail Chains",
      buyerType: "Supermarket Chain",
      verified: true,
      location: "Bangalore & Hyderabad Hubs",
      cropNeeded: "Tomato",
      variety: "Firm Hybrid Red",
      targetQty: 300,
      unit: "quintal",
      offeringPrice: 2150,
      deliveryDeadline: "2026-09-05",
      urgency: "High",
      paymentTerms: "100% Escrow on dispatch, release within 2 hours of delivery",
      description: "Weekly recurring requirement for 30 supermarket outlets. Crate packed produce preferred. Direct farm pickup available for lots > 50 quintals."
    },
    {
      id: "dem-202",
      buyerId: "buyer-2",
      buyerName: "Taj & Spice Hospitality Group",
      buyerType: "Restaurant Group",
      verified: true,
      location: "Mumbai, Maharashtra",
      cropNeeded: "Onion",
      variety: "Nashik Medium (45-55mm)",
      targetQty: 80,
      unit: "quintal",
      offeringPrice: 2900,
      deliveryDeadline: "2026-09-02",
      urgency: "Urgent",
      paymentTerms: "Direct digital UPI / Escrow on delivery",
      description: "Immediate delivery needed for central kitchen. Consistent supply contracts available for reliable farmer groups."
    },
    {
      id: "dem-203",
      buyerId: "buyer-3",
      buyerName: "Annapurna Roller Flour Mills",
      buyerType: "Food Processor / Mill",
      verified: true,
      location: "Indore, MP",
      cropNeeded: "Wheat",
      variety: "Sharbati / Lokwan (Moisture < 12%)",
      targetQty: 1000,
      unit: "quintal",
      offeringPrice: 2880,
      deliveryDeadline: "2026-09-15",
      urgency: "Normal",
      paymentTerms: "Bank NEFT via KisanSetu Escrow",
      description: "Bulk procurement for packaged atta brand. Direct unloading at factory silo. Group farmers / FPOs welcome."
    },
    {
      id: "dem-204",
      buyerId: "buyer-4",
      buyerName: "GreenGrocer D2C Platform",
      buyerType: "E-Commerce Fresh",
      verified: true,
      location: "Delhi NCR Hub",
      cropNeeded: "Potato",
      variety: "Chipsona / Jyoti",
      targetQty: 150,
      unit: "quintal",
      offeringPrice: 1520,
      deliveryDeadline: "2026-09-04",
      urgency: "High",
      paymentTerms: "Instant Escrow release",
      description: "Looking for unwashed, disease-free table potatoes graded 50mm+. Gunny bags or mesh bags."
    }
  ],

  // 4. Group Selling / FPO Collective Pools
  groupPools: [
    {
      id: "pool-301",
      title: "Guntur Organic Red Chilli Pool 2026",
      fpoName: "Krishna River Valley FPO",
      leadFarmer: "Anji Reddy",
      crop: "Red Chilli",
      variety: "Teja Super Hot",
      targetQty: 250,
      currentQty: 195,
      unit: "quintal",
      farmersCount: 14,
      agreedBasePrice: 22400,
      negotiatedBuyer: "ITC Agri Spices Export Div",
      buyerOfferedPrice: 23200,
      extraEarningsPerFarmer: "₹800 / quintal bonus",
      status: "Pooling Active (80% Full)",
      daysLeft: 4,
      sharedLogisticsSaving: "Save 42% on freight via collective 16-wheeler container"
    },
    {
      id: "pool-302",
      title: "Nashik Small Farmers Onion Export Pool",
      fpoName: "Sahyadri Kisan Sangathan",
      leadFarmer: "Pravin Jagtap",
      crop: "Onion",
      variety: "Garwa Red (55mm+)",
      targetQty: 500,
      currentQty: 410,
      unit: "quintal",
      farmersCount: 26,
      agreedBasePrice: 3000,
      negotiatedBuyer: "Gulf Food Trade Importers",
      buyerOfferedPrice: 3250,
      extraEarningsPerFarmer: "₹250 / quintal bonus",
      status: "Closing Soon (82% Full)",
      daysLeft: 2,
      sharedLogisticsSaving: "Direct port refrigerated truck booking"
    }
  ],

  // 5. Smart Logistics & Transporter Directory
  transporters: [
    {
      id: "truck-1",
      driverName: "Balwinder Singh",
      vehicleType: "Tata 407 (3.5 Ton / 35 Quintals)",
      phone: "+91 98888 12345",
      rating: 4.9,
      tripsDone: 142,
      currentLocation: "Guntur Mandi Hub",
      baseRatePerKm: 24,
      capacityQuintals: 35,
      liveAvailable: true
    },
    {
      id: "truck-2",
      driverName: "Kishore Kumar",
      vehicleType: "Eicher 1114 (10 Ton / 100 Quintals)",
      phone: "+91 97777 56789",
      rating: 4.8,
      tripsDone: 210,
      currentLocation: "Nashik Bypass",
      baseRatePerKm: 42,
      capacityQuintals: 100,
      liveAvailable: true
    },
    {
      id: "truck-3",
      driverName: "Shiva Reddy",
      vehicleType: "Tractor Trolley (5 Ton / 50 Quintals)",
      phone: "+91 96666 34567",
      rating: 4.7,
      tripsDone: 88,
      currentLocation: "Kurnool Local Area",
      baseRatePerKm: 18,
      capacityQuintals: 50,
      liveAvailable: true
    }
  ],

  // 6. Active Orders / Escrow Transactions
  orders: [
    {
      id: "ORD-9021",
      listingId: "list-101",
      crop: "Paddy (Rice)",
      variety: "Sona Masoori",
      quantity: 40,
      unit: "quintal",
      dealPricePerUnit: 2550,
      totalAmount: 102000,
      escrowStatus: "Funded & Secured",
      farmerName: "Rameshwar Patel",
      buyerName: "FreshBazaar Retail",
      step: 3,
      timeline: [
        { title: "Deal Agreed at ₹2,550/qtl", time: "Aug 28, 11:30 AM", done: true },
        { title: "Buyer Deposited ₹1,02,000 in Escrow", time: "Aug 28, 01:15 PM", done: true },
        { title: "Produce Packed & Loaded on Truck #AP07-TY-4421", time: "Aug 29, 07:00 AM", done: true },
        { title: "Transit to Bangalore Fulfillment Hub", time: "In Progress (ETA: 4h)", done: false },
        { title: "Quality Check & Auto Payment Release", time: "Pending Delivery", done: false }
      ]
    }
  ],

  // 7. Simulated Chat Conversations for Bargaining
  chatThreads: {
    "list-101": [
      { sender: "buyer", text: "Namaste Rameshwar ji! I saw your 80 quintals Sona Masoori paddy. Can you provide 40 quintals to Hyderabad hub?", time: "10:14 AM" },
      { sender: "farmer", text: "Namaste Sir! Yes, moisture is 12.8% certified by AI scanner. Asking price is ₹2,580/quintal.", time: "10:18 AM" },
      { sender: "buyer", text: "Can we close at ₹2,520/quintal if we book our own transport?", time: "10:22 AM" },
      { sender: "farmer", text: "Mandi price is ₹2,450. I can offer ₹2,550 final with high grade gunny bags included.", time: "10:25 AM" },
      { sender: "buyer", isOffer: true, offerPrice: 2550, offerQty: 40, text: "🤝 Agreed! Placed official offer for 40 quintals @ ₹2,550/qtl (Total: ₹1,02,000). Escrow ready.", time: "10:30 AM" }
    ]
  },

  // 8. Sample Produce AI Scans
  sampleProduceScans: [
    {
      id: "scan-sample-1",
      cropName: "Tomato",
      variety: "Hybrid Himsona (Roma Type)",
      freshnessScore: 94,
      grade: "Grade A+ (Supermarket / Export)",
      ripenessStage: "Firm Ripe (Stage 5)",
      moistureEst: "92.4%",
      blemishDefectPct: "1.2%",
      shelfLifeDays: "12 - 14 days",
      confidence: "98.6%",
      colorProfile: "Deep Crimson Red (Uniform)",
      aiAdvice: "Excellent firm texture with low puncture risk. Safe for up to 600km transit without cold chain loss.",
      recommendedPrice: "₹2,100 - ₹2,300 / quintal",
      imageUrl: "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=600&q=80"
    },
    {
      id: "scan-sample-2",
      cropName: "Onion",
      variety: "Nashik Red Garwa",
      freshnessScore: 91,
      grade: "Grade A (Wholesale / Retail)",
      ripenessStage: "Well-cured Dry Neck",
      moistureEst: "11.2% (Dry scale)",
      blemishDefectPct: "2.5%",
      shelfLifeDays: "60 - 90 days",
      confidence: "97.2%",
      colorProfile: "Glossy Ruby Red with intact papery tunic",
      aiAdvice: "Outer skin layers are dry and firm. Zero sprouting detected. Suitable for bulk warehousing.",
      recommendedPrice: "₹2,800 - ₹3,100 / quintal",
      imageUrl: "https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?auto=format&fit=crop&w=600&q=80"
    },
    {
      id: "scan-sample-3",
      cropName: "Wheat",
      variety: "Sharbati Golden Grain",
      freshnessScore: 96,
      grade: "Grade A+ (Premium Atta / Export)",
      ripenessStage: "Fully Mature Dry Grain",
      moistureEst: "11.1%",
      blemishDefectPct: "0.8%",
      shelfLifeDays: "360 days",
      confidence: "99.1%",
      colorProfile: "Golden Amber, High Glassiness",
      aiAdvice: "High hectolitre weight detected with minimal broken grains (<0.5%). High gluten potential.",
      recommendedPrice: "₹2,850 - ₹3,150 / quintal",
      imageUrl: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=600&q=80"
    }
  ],

  // 9. Better Farmer Diagnostic Assessment Questions
  betterFarmerQuestions: [
    {
      id: "q1",
      category: "Soil Health & Nutrients",
      question: "How do you test and manage your soil nutrients before sowing?",
      options: [
        { label: "Lab Soil Health Card test every season + targeted N-P-K & Bio-fertilizer", points: 25, improvementAction: "Keep testing micro-nutrients (Zinc & Boron) to sustain high yield.", potentialGain: "+15% yield gain" },
        { label: "Apply standard DAP & Urea bags based on visual experience", points: 15, improvementAction: "Conduct Soil Health Card test to reduce excess chemical fertilizer cost by 30%.", potentialGain: "Save ₹4,500/acre on fertilizer" },
        { label: "Rarely test soil; apply whatever neighbor farmers are applying", points: 5, improvementAction: "Book a doorstep mobile soil test lab voucher below to know your soil pH and Organic Carbon.", potentialGain: "+25% crop growth improvement" }
      ]
    },
    {
      id: "q2",
      category: "Water & Irrigation Management",
      question: "What is your primary irrigation method on your farm?",
      options: [
        { label: "Drip / Micro-sprinkler irrigation with timer or moisture sensor", points: 25, improvementAction: "Excellent water management! Maintain flush filters bi-monthly.", potentialGain: "Saves 45% water & power" },
        { label: "Furrow / Controlled pipe irrigation from tube-well or canal", points: 15, improvementAction: "Switching to subsidized solar drip system can boost fruit firmness and grade.", potentialGain: "Upgrade to Grade A+ produce" },
        { label: "Flood irrigation / dependent entirely on seasonal rainfall", points: 5, improvementAction: "Adopt mulching sheets and farm pond rainwater harvesting to prevent drought stress.", potentialGain: "Protects against 40% crop loss" }
      ]
    },
    {
      id: "q3",
      category: "Post-Harvest Handling & Grading",
      question: "How do you handle produce immediately after harvesting?",
      options: [
        { label: "Shade drying, mechanical cleaning, and grading into A/B/C lots", points: 25, improvementAction: "Continue standard grading to attract export buyers and supermarket contracts.", potentialGain: "+₹180/quintal price premium" },
        { label: "Direct field bagging without size or moisture grading", points: 10, improvementAction: "Use our AI Produce Scanner to grade sizes and claim Grade A certificates.", potentialGain: "+₹100/quintal over mandi rate" },
        { label: "Sell bulk standing crop to village trader at lump-sum price", points: 0, improvementAction: "Stop selling unweighed standing crops; list on KisanSetu directly to retail buyers.", potentialGain: "Eliminates 20% middleman margin" }
      ]
    },
    {
      id: "q4",
      category: "Pest & Crop Protection",
      question: "How do you detect and treat crop pest attacks or fungus?",
      options: [
        { label: "Pheromone sticky traps + biological neem oil sprays before threshold", points: 25, improvementAction: "Maintain IPM records to qualify for Zero Chemical Residue certifications.", potentialGain: "Eligible for organic export rates" },
        { label: "Spray chemical pesticide when attack is visible on 20%+ leaves", points: 15, improvementAction: "Install early pheromone trap lures to catch pests before egg-laying cycle.", potentialGain: "Cuts spray costs by 50%" },
        { label: "Spray heavy cocktails from local dealer when whole crop is damaged", points: 5, improvementAction: "Use photo disease scanning and early advisory to avoid crop burning.", potentialGain: "Saves crop from total destruction" }
      ]
    }
  ],

  // 10. Reward Discount Vouchers (Redeemable in Kisan Wallet)
  rewardVouchers: [
    {
      id: "vouch-1",
      title: "15% Discount on Certified Bio-Seeds & Hybrids",
      partner: "National Seeds Corp / AgriJunction",
      discountValue: "15% OFF",
      requiredScore: 40,
      couponCode: "KISAN-BIO-15",
      unlocked: true,
      isRedeemed: false,
      description: "Valid on certified high-germination Paddy, Wheat, Cotton and Vegetable seed varieties."
    },
    {
      id: "vouch-2",
      title: "₹500 Freight Subsidy on Mandi Transport",
      partner: "KisanSetu Rural Logistics Fleet",
      discountValue: "₹500 OFF",
      requiredScore: 60,
      couponCode: "KISAN-TRUCK-500",
      unlocked: false,
      isRedeemed: false,
      description: "Instant discount on any Tata Ace or 10-Ton truck booking for loads > 20 quintals."
    },
    {
      id: "vouch-3",
      title: "Free Doorstep Soil Health Test (16 Parameters)",
      partner: "Krishi Vigyan Soil Lab",
      discountValue: "100% FREE (Valued ₹850)",
      requiredScore: 75,
      couponCode: "SOIL-CARE-FREE",
      unlocked: false,
      isRedeemed: false,
      description: "Doorstep soil sample collection with digital N-P-K, organic carbon, and pH report in 48h."
    },
    {
      id: "vouch-4",
      title: "20% OFF Solar Drip & Automation Kit Rental",
      partner: "Jain & Netafim Agri Rentals",
      discountValue: "20% OFF",
      requiredScore: 85,
      couponCode: "DRIP-SMART-20",
      unlocked: false,
      isRedeemed: false,
      description: "Discount on seasonal rental of smart solar fertigation and drip automation controllers."
    }
  ],

  // 11. Multi-Variable ML Calibration Feedback Logs
  mlHistoricalFeedback: [
    { date: "Aug 15", crop: "Tomato", actualMandi: 1850, initialPredicted: 1720, recalibratedPredicted: 1840, errorPct: "0.5%", factors: "Rainfall deficit in Kolar accurately learned" },
    { date: "Aug 22", crop: "Onion", actualMandi: 2950, initialPredicted: 3180, recalibratedPredicted: 2965, errorPct: "0.5%", factors: "Export restriction policy weights adjusted" },
    { date: "Aug 27", crop: "Paddy", actualMandi: 2580, initialPredicted: 2520, recalibratedPredicted: 2575, errorPct: "0.2%", factors: "Mill procurement surge weights self-corrected" }
  ],

  // 12. Peer Farmers for Matchmaking & Farm Duels
  peerFarmers: [
    {
      id: "peer-1",
      name: "Srinivas Rao",
      location: "Tenali, Guntur AP (12 km away)",
      landAcres: 4.5,
      soilType: "Black Alluvial",
      crop: "Paddy (Rice)",
      variety: "Sona Masoori",
      equipment: ["Drip Kit", "Tractor", "Laser Leveler"],
      yieldPerAcre: 29.2,
      qualityScorePct: 96,
      avgPriceRealized: 2610,
      mandiBenchmark: 2450,
      waterEfficiencyScore: 95,
      kisanPowerScore: 920,
      rank: 2,
      avatar: "🌾"
    },
    {
      id: "peer-2",
      name: "Harpreet Singh",
      location: "Khanna, Ludhiana PB",
      landAcres: 5.0,
      soilType: "Alluvial Loam",
      crop: "Wheat",
      variety: "Sharbati Gold",
      equipment: ["Combine Harvester", "Rotavator", "Solar Pump"],
      yieldPerAcre: 31.0,
      qualityScorePct: 92,
      avgPriceRealized: 2940,
      mandiBenchmark: 2850,
      waterEfficiencyScore: 88,
      kisanPowerScore: 875,
      rank: 5,
      avatar: "🚜"
    },
    {
      id: "peer-3",
      name: "Shankar Patil",
      location: "Niphad, Nashik MH",
      landAcres: 4.0,
      soilType: "Black Loam",
      crop: "Onion",
      variety: "Garwa Red",
      equipment: ["Drip Fertigation", "Curing Shed"],
      yieldPerAcre: 110.0,
      qualityScorePct: 95,
      avgPriceRealized: 2980,
      mandiBenchmark: 2750,
      waterEfficiencyScore: 94,
      kisanPowerScore: 940,
      rank: 1,
      avatar: "🧅"
    }
  ],

  // 13. District & State Monthly Farmer Leaderboard
  farmerLeaderboard: [
    { rank: 1, name: "Shankar Patil", district: "Nashik, MH", powerScore: 940, yieldEfficiency: "+22%", rewardBadge: "Master Kisan 🏆" },
    { rank: 2, name: "Srinivas Rao", district: "Guntur, AP", powerScore: 920, yieldEfficiency: "+18%", rewardBadge: "Agri Leader ⭐" },
    { rank: 3, name: "Anand Verma", district: "Indore, MP", powerScore: 905, yieldEfficiency: "+15%", rewardBadge: "Gold Farmer 🥇" },
    { rank: 4, name: "Gowtham Kisan (You)", district: "Guntur, AP", powerScore: 890, yieldEfficiency: "+14%", rewardBadge: "Silver Farmer 🥈" },
    { rank: 5, name: "Harpreet Singh", district: "Ludhiana, PB", powerScore: 875, yieldEfficiency: "+11%", rewardBadge: "Progressive Kisan 🌾" }
  ],

  // 14. Regional Climate Risk Profiles
  climateRegionProfiles: [
    {
      id: "region-1",
      name: "Deccan Plateau (Semi-Arid)",
      states: "Telangana, Andhra Pradesh, Maharashtra, Karnataka",
      rainfallShift: "-18% monsoon delay with sudden unseasonal cloudbursts",
      tempRise: "+1.8°C average summer heat spike",
      groundwaterTable: "Critical Depletion (Down 45 ft in 5 years)",
      waterDeficitIndex: 85,
      heatwaveIndex: 80
    },
    {
      id: "region-2",
      name: "Indo-Gangetic Plains",
      states: "Punjab, Haryana, Uttar Pradesh, Bihar",
      rainfallShift: "-12% erratic monsoon & dense winter fog fluctuations",
      tempRise: "+2.1°C terminal heat during grain-filling stage",
      groundwaterTable: "Severe Over-Exploitation",
      waterDeficitIndex: 78,
      heatwaveIndex: 88
    },
    {
      id: "region-3",
      name: "Western Arid & Semi-Arid",
      states: "Rajasthan, Gujarat, MP West",
      rainfallShift: "-25% drought cycles with intense short showers",
      tempRise: "+2.4°C extreme heatwave frequency",
      groundwaterTable: "Saline & Deep Aquifer Strain",
      waterDeficitIndex: 94,
      heatwaveIndex: 92
    }
  ],

  // 15. Climate-Smart Alternative Crops
  climateResilientCrops: [
    {
      id: "alt-1",
      name: "Pearl Millet (Bajra) / Hybrid Ragi",
      category: "Superfood Millet (Nutri-Cereal)",
      resilienceScore: 96,
      waterReductionPct: "65% less water than Paddy",
      costReductionPct: "45% lower fertilizer & seed cost",
      marketPricePerQtl: 3850,
      estimatedNetProfitPerAcre: "₹52,000 / acre",
      maturityDays: "75 - 85 days",
      idealSowingWindow: "June - July (Kharif) or Oct (Rabi)",
      seedRatePerAcre: "3.5 - 4 kg / acre",
      hasGovtMSP: true,
      mspRate: "₹2,625 / qtl (Govt Guaranteed Base)",
      carbonBenefit: "Zero methane emissions; builds root organic carbon",
      buyerDemandNetwork: "ITC Superfoods, Tata Soulfull, Direct Exporters",
      description: "Thrives in temperatures up to 44°C and requires only 250-350mm rainfall. Exceptional urban demand for diabetic-friendly flour."
    },
    {
      id: "alt-2",
      name: "Dragon Fruit (Kamalam / Pitaya)",
      category: "High-Value Arid Horticulture",
      resilienceScore: 94,
      waterReductionPct: "80% less water via drip irrigation",
      costReductionPct: "Low recurring maintenance after trellis setup",
      marketPricePerQtl: 14000,
      estimatedNetProfitPerAcre: "₹1,80,000 / acre (Year 2 onwards)",
      maturityDays: "Perennial (Harvest in 30 days per fruiting cycle)",
      idealSowingWindow: "July - September planting",
      seedRatePerAcre: "1,800 rooted cuttings / acre",
      hasGovtMSP: false,
      mspRate: "Free Market (₹120 - ₹180 / kg retail)",
      carbonBenefit: "CAM photosynthetic cactus absorbing night carbon",
      buyerDemandNetwork: "Supermarket chains, Premium fruit exporters, Quick Commerce",
      description: "Cactus family plant requiring minimal water. Produces high-value fruit for 18-20 years with zero susceptibility to typical locust or flood rot."
    },
    {
      id: "alt-3",
      name: "Organic Moringa (Drumstick Pods & Leaves)",
      category: "Drought-Resilient Agroforestry",
      resilienceScore: 92,
      waterReductionPct: "70% water savings",
      costReductionPct: "50% lower input cost",
      marketPricePerQtl: 4800,
      estimatedNetProfitPerAcre: "₹75,000 / acre",
      maturityDays: "160 days to first harvest, then continuous",
      idealSowingWindow: "Year-round with drip",
      seedRatePerAcre: "500g PKM-1 hybrid seeds / acre",
      hasGovtMSP: false,
      mspRate: "Export Market Premium (₹40 - ₹65 / kg pods)",
      carbonBenefit: "Deep taproot system arresting soil erosion",
      buyerDemandNetwork: "Pharma nutraceutical brands, Spice exporters, Metro mandis",
      description: "Extremely resilient deep-root perennial. Leaves sell for herbal extracts while pods command high weekly cash flow."
    },
    {
      id: "alt-4",
      name: "Desi Chickpea (Chana) & Black Wheat",
      category: "Nutrient-Dense Climate Rabi Crop",
      resilienceScore: 90,
      waterReductionPct: "55% less water than Conventional Wheat",
      costReductionPct: "30% lower cost (Fixes its own Nitrogen)",
      marketPricePerQtl: 5600,
      estimatedNetProfitPerAcre: "₹46,000 / acre",
      maturityDays: "95 - 110 days",
      idealSowingWindow: "October - November",
      seedRatePerAcre: "30 - 35 kg / acre",
      hasGovtMSP: true,
      mspRate: "₹5,440 / qtl",
      carbonBenefit: "Atmospheric nitrogen fixing (Adds 40kg N/ha into soil)",
      buyerDemandNetwork: "Dal millers, Organics packaged brands, FCI procurement",
      description: "High antioxidant Anthocyanin grain with high tolerance to winter temperature spikes. Eliminates urea requirements."
    }
  ],

  // 16. Climate Transition Government Subsidies
  climateSubsidies: [
    {
      id: "sub-1",
      title: "National Shree Anna (Millet) Promotion Scheme",
      benefit: "₹10,000 / hectare direct cash incentive + 80% subsidized certified seeds",
      applicableCrops: ["Pearl Millet (Bajra) / Hybrid Ragi", "All Climate-Smart"],
      agency: "Ministry of Agriculture & State Dept",
      linkText: "Apply via Kisan Portal"
    },
    {
      id: "sub-2",
      title: "National Horticulture Mission - Dragon Fruit Trellis Grant",
      benefit: "Up to ₹1,20,000 / hectare subsidy for cement pole support structures & drip line",
      applicableCrops: ["Dragon Fruit (Kamalam / Pitaya)"],
      agency: "National Horticulture Board (NHB)",
      linkText: "Check District Eligibility"
    },
    {
      id: "sub-3",
      title: "Per Drop More Crop (Micro-Irrigation Subsidy)",
      benefit: "Up to 90% subsidy on Solar Drip Kits for Small & Marginal Farmers",
      applicableCrops: ["All Climate-Smart"],
      agency: "PMKSY Water Mission",
      linkText: "Instant Pre-Approval"
    }
  ]
};

if (typeof window !== 'undefined') {
  window.SEED_DATA = SEED_DATA;
}
